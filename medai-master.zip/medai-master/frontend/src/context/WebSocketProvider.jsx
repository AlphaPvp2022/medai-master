// import React, { createContext, useEffect, useRef } from 'react';

// export const WebSocketContext = createContext(null);

// export const WebSocketProvider = ({ children }) => {
//   const socketRef = useRef(null);

//   useEffect(() => {
//     const token = localStorage.getItem('access_token');
//     if (!token) return;

//     socketRef.current = new WebSocket(`ws://localhost:8000/ws/your_channel/?token=${token}`);

//     socketRef.current.onopen = () => {
//       console.log('✅ WebSocket connected');
//     };

//     socketRef.current.onmessage = (event) => {
//       console.log('📨 Message received:', event.data);
//     };

//     socketRef.current.onerror = (error) => {
//       console.error('WebSocket error:', error);
//     };

//     socketRef.current.onclose = () => {
//       console.log('❌ WebSocket closed');
//     };

//     return () => {
//       socketRef.current.close();
//     };
//   }, []);

//   return (
//     <WebSocketContext.Provider value={socketRef}>
//       {children}
//     </WebSocketContext.Provider>
//   );
// };

import React, { createContext, useEffect, useRef, useState } from 'react';

export const WebSocketContext = createContext(null);

export const WebSocketProvider = ({ children }) => {
  const socketRef = useRef(null);
  const [messages, setMessages] = useState([]);
  const [currentToken, setCurrentToken] = useState(() => localStorage.getItem('access_token'));

  useEffect(() => {
    const interval = setInterval(() => {
      const latestToken = localStorage.getItem('access_token');
      if (latestToken && latestToken !== currentToken) {
        setCurrentToken(latestToken); // Trigger reconnection
      }
    }, 3000); // Poll every 3 seconds

    return () => clearInterval(interval);
  }, [currentToken]);

  useEffect(() => {
    if (!currentToken) return;

    const wsUrl = `ws://localhost:8000/ws/file-processing/?token=${currentToken}`;
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    console.log("🔌 Opening WebSocket with token:", currentToken);

    socket.onopen = () => {
      console.log('✅ WebSocket connected');
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'progress') {
          console.log('📨 Progress update:', data.message);
          setMessages((prev) => [...prev, data.message]);
        } else {
          console.log('ℹ️ Unknown message type:', data);
        }
      } catch (err) {
        console.error('❌ Error parsing WebSocket message:', err);
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = (e) => {
      console.warn('❌ WebSocket closed', e.reason || "");
    };

    return () => {
      socket.close();
      console.log('🔌 WebSocket connection closed');
    };
  }, [currentToken]);

  return (
    <WebSocketContext.Provider value={{ socketRef, messages }}>
      {children}
    </WebSocketContext.Provider>
  );
};

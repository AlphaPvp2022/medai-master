import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

const baseURL = "http://localhost:8000/api";

function useUserActions() {
  const navigate = useNavigate();
  const [user, setUser] = useState(getUser());

  useEffect(() => {
    // ✅ Listen for localStorage changes (detects login/logout across tabs)
    const storageListener = () => {
      const updatedUser = getUser();
      setUser(updatedUser);
      console.log("🔄 User state updated from localStorage:", updatedUser);
    };

    window.addEventListener("storage", storageListener);

    return () => {
      window.removeEventListener("storage", storageListener);
    };
  }, []);

  return {
    login: async (data) => {
      try {
        const res = await axios.post(`${baseURL}/auth/login/`, data);
        setUserData(res.data);
        setUser(res.data.user);
        console.log("✅ Login successful, navigating to dashboard...");
        navigate("/dashboard");
      } catch (error) {
        console.error("🔴 Login error:", error.response?.data || error.message);
      }
    },
    register: async (data) => {
      try {
        const res = await axios.post(`${baseURL}/auth/register/`, data);
        setUserData(res.data);
        setUser(res.data.user);
        console.log("✅ Registration successful, navigating to dashboard...");
        navigate("/dashboard");
      } catch (error) {
        console.error("🔴 Registration error:", error.response?.data || error.message);
      }
    },
    logout: () => {
      console.log("🔴 Logging out...");
      localStorage.removeItem("auth");
      setUser(null);
      navigate("/login");
    },
  };
}

function setUserData(data) {
  if (!data.user) {
    console.error("🔴 ERROR: No user data received from API.");
    return;
  }

  const authData = {
    access: data.access,
    refresh: data.refresh,
    user: data.user, 
  };

  localStorage.setItem("auth", JSON.stringify(authData));

  // console.log("🔵 Saved to localStorage:", authData); 
}

function getUser() {
  const auth = JSON.parse(localStorage.getItem("auth")) || null;
  return auth ? auth.user : null;
}

function getAccessToken() {
  const auth = JSON.parse(localStorage.getItem("auth"));
  return auth ? auth.access : null;
}

export { useUserActions, getUser, getAccessToken };

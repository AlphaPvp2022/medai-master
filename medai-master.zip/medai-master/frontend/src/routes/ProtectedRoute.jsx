import { Navigate } from "react-router-dom";
import { getUser, getAccessToken } from "../hooks/user.actions";
import { jwtDecode } from "jwt-decode";
import { useState, useEffect } from "react";

function isTokenExpired(token) {
  if (!token) return true;
  try {
    const { exp } = jwtDecode(token);
    return Date.now() >= exp * 1000;
  } catch (e) {
    return true;
  }
}

function ProtectedRoute({ children }) {
  const [user, setUser] = useState(getUser());
  const [accessToken, setAccessToken] = useState(getAccessToken());

  useEffect(() => {
    const checkAuth = () => {
      const newUser = getUser();
      const newToken = getAccessToken();
      setUser(newUser);
      setAccessToken(newToken);
    };

    checkAuth();

    // Listen for storage changes to detect logout in other tabs
    const storageListener = () => {
      checkAuth();
    };

    window.addEventListener("storage", storageListener);

    return () => {
      window.removeEventListener("storage", storageListener);
    };
  }, []);

  if (!user || !accessToken || isTokenExpired(accessToken)) {
    return <Navigate to="/login/" />;
  }

  return <>{children}</>;
}

export default ProtectedRoute;

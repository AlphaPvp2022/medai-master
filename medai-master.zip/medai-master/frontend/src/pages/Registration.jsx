import React from "react";
import { Link } from "react-router-dom";
import RegistrationForm from "../components/authentication/RegistrationForm";
import "../styles/auth/login.css";

const translations = {
  "en": {
    createAccount: "Create Your Account",
    description: "Sign up to access Medical AI services.",
    alreadyHaveAccount: "Already have an account?",
    login: "Login here",
  },
  'ru': {
    createAccount: "Создайте свою учетную запись",
    description: "Зарегистрируйтесь, чтобы получить доступ к услугам Medical AI.",
    alreadyHaveAccount: "Уже есть аккаунт?",
    login: "Войти здесь",
  },
  'uk': {
    createAccount: "Створіть свій обліковий запис",
    description: "Зареєструйтеся, щоб отримати доступ до послуг Medical AI.",
    alreadyHaveAccount: "У вас вже є обліковий запис?",
    login: "Увійти тут",
  }
}

function Registration() {
  const lang = localStorage.getItem("language") || "en";
  const t = translations[lang];

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-content">
          <h1 className="auth-title">{t.createAccount}</h1>
          <p className="auth-description">
            {t.description}<br />
            {t.alreadyHaveAccount} <Link to="/login/">{t.login}</Link>
          </p>
        </div>
        <div className="auth-form-container">
          <div className="auth-card">
            <RegistrationForm />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Registration;

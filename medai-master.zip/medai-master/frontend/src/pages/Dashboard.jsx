import React, { useState, useEffect, useRef, useLayoutEffect } from "react";
import Sidebar from "../components/dashboard/Sidebar";
import LanguageSelector from "../components/dashboard/LanguageSelector";
import api from "../helpers/axios";
import "../styles/dashboard.css";

const Dashboard = () => {
  const [sessions, setSessions] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);
  const [input, setInput] = useState("");
  const [attachedFiles, setAttachedFiles] = useState([]);
  const inputRef = useRef(null);
  const bottomRef = useRef(null);
  const [showLangPopup, setShowLangPopup] = useState(() => !localStorage.getItem("language"));
  const [errorMessage, setErrorMessage] = useState(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState("");

  const lang = localStorage.getItem("language") || "en";
  const t = {
    en: {
      maxFiles: "Max 10 files allowed.",
      maxSize: "Combined file size exceeds 10MB.",
      send: 'Send',
    },
    ru: {
      maxFiles: "Максимум 10 файлов.",
      maxSize: "Суммарный размер файлов превышает 10МБ.",
      send: 'Отправить',
    },
    uk: {
      maxFiles: "Максимум 10 файлів.",
      maxSize: "Сумарний розмір перевищує 10МБ.",
      send: 'Відправити',
    },
  }[lang];

  useLayoutEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
    }
  }, [input]);

  useEffect(() => {
    fetchChatSessions();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchChatSessions = async () => {
    try {
      const res = await api.get("/chat/sessions/");
      setSessions(res.data);
      if (res.data.length > 0 && !currentChatId) {
        const firstChatId = res.data[0].id;
        setCurrentChatId(firstChatId);
        await loadChat(firstChatId);
      }
    } catch (err) {
      console.error("Failed to fetch sessions", err);
    }
  };
  

  const loadChat = async (chatId) => {
    try {
      const res = await api.get(`/chat/sessions/${chatId}/`);
      const restored = res.data.messages.map((msg) => {
        if (msg.text?.startsWith("[FILES] ")) {
          const filenames = msg.text.replace("[FILES] ", "").split("|");
          return {
            ...msg,
            // Preserve the text if there's additional content (not just a file marker)
            text: msg.text.includes("|") ? null : msg.text,
            attachments: filenames.map((name) => ({
              type: name.match(/\.(jpg|jpeg|png)$/i) ? "image" : "file",
              name,
              url: `/media/${name}`, // ✅ ensures broken images are avoided
            })),
          };
        }
  
        // If attachments already exist, set default URLs if missing
        const mappedAttachments = (msg.attachments || []).map((a) => ({
          ...a,
          url: a.url || (a.type === "image" ? `/media/${a.name}` : null),
        }));
  
        return {
          ...msg,
          attachments: mappedAttachments,
        };
      });
      setChatMessages(restored);
    } catch (err) {
      console.error("Failed to load chat", err);
    }
  };
  

  const formatMarkdown = (text) => {
    return text
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.+?)\*/g, "<em>$1</em>")
      .replace(/`(.+?)`/g, "<code>$1</code>")
      .replace(/\n/g, "<br>");
  };

  const handleFileInput = (e) => {
    const files = Array.from(e.target.files);
    const newFiles = [];
    let totalSize = attachedFiles.reduce((acc, f) => acc + f.size, 0);

    for (const file of files) {
      if (attachedFiles.length + newFiles.length >= 10) {
        setErrorMessage(t.maxFiles);
        break;
      }
      
      if (totalSize + file.size > 10 * 1024 * 1024) {
        setErrorMessage(t.maxSize);
        break;
      }

      newFiles.push(file);
      totalSize += file.size;
    }

    setAttachedFiles((prev) => [...prev, ...newFiles]);
    e.target.value = null;
  };

  const handleFileUploadWithInput = async () => {
    if (!input.trim() && attachedFiles.length === 0) return;

    const formData = new FormData();
    formData.append("message", input);
    formData.append("chat_id", currentChatId);

    const filePreviews = attachedFiles.map((file) => {
      if (file.type.startsWith("image/")) {
        return {
          type: "image",
          name: file.name,
          url: URL.createObjectURL(file),
        };
      } else {
        return {
          type: "file",
          name: file.name,
        };
      }
    });

    attachedFiles.forEach((file) => {
      formData.append("file", file);
    });

    setChatMessages((prev) => [
      ...prev,
      {
        sender: "user",
        text: input.trim() ? input : null,
        attachments: filePreviews.length > 0 ? filePreviews : undefined,
      },
      {
        sender: "bot",
        text: "...",
        attachments: filePreviews.length > 0 ? filePreviews : undefined,
      },
    ]);
    

    setInput("");
    setAttachedFiles([]);

    try {
      const res = await api.post("/chat/process-file-and-input/", formData);
      const reply = res.data.reply || "(No reply)";
    
      setStreamingText("");
      setIsStreaming(true);
    
      let i = 0;
      let replyText = "";
    
      const streamInterval = setInterval(() => {
        if (i >= reply.length) {
          clearInterval(streamInterval);
          setIsStreaming(false);
    
          setChatMessages((prev) => {
            const updated = [...prev];
            updated[updated.length - 1] = {
              ...updated[updated.length - 1],
              text: replyText,
            };
            return updated;
          });
    
          setStreamingText("");
          return;
        }
    
        replyText += reply[i];
        setStreamingText(replyText);
        i++;
      }, 10);
    
      setTimeout(() => {
        fetchChatSessions();
        loadChat(currentChatId);
      }, 500);
    
      await fetchChatSessions();
      await loadChat(currentChatId);
    
    } catch (err) {
      const msg =
        err.response?.data?.error ||
        err.message ||
        "Something went wrong. Please try again.";
      setErrorMessage(msg);
      setChatMessages((prev) => prev.slice(0, -1));
    }
    
  };

  return (
    <div className="chat-dashboard">
      {showLangPopup && <LanguageSelector onSelect={(lang) => {
        localStorage.setItem("language", lang);
        setShowLangPopup(false);
      }} />}

      <Sidebar
        sessions={sessions}
        setSessions={setSessions}  
        currentChatId={currentChatId}
        setCurrentChatId={setCurrentChatId} 
        onSelectChat={(id) => {
          setCurrentChatId(id);
          loadChat(id);
        }}
        onNewChat={async () => {
          const res = await api.post("/chat/new/");
          setCurrentChatId(res.data.chat_id);
          await fetchChatSessions();
          loadChat(res.data.chat_id);
        }}
      />


      <div className="chat-main">
        <div className="chat-window">
        {errorMessage && (
          <div className="error-banner">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage(null)}>✖</button>
          </div>
        )}
          <div className="chat-messages full-width-chat">
            <div className="chat-content-wrapper">
              {chatMessages.map((msg, idx) => (
                <div key={idx} className={`chat-line ${msg.sender}`}>
                  <div className="chat-bubble">
                    {msg.attachments?.map((a, i) =>
                      a.type === "image" ? (
                        <div className="chat-image-block" key={i}>
                          <img
                            src={a.url || `/media/${a.name}`}
                            alt={a.name}
                            className="chat-image-thumb"
                          />
                          <div className="chat-image-name">{a.name}</div>
                        </div>
                      ) : (
                        <div className="chat-file-attachment" key={i}>
                          📎 {a.name}
                        </div>
                      )
                    )}

                    {/* Correctly handle streaming text if it's the latest bot message */}
                    {msg.sender === "bot" && idx === chatMessages.length - 1 && isStreaming ? (
                      <div
                        dangerouslySetInnerHTML={{
                          __html: formatMarkdown(streamingText),
                        }}
                      />
                    ) : (
                      msg.text && (
                        <div
                          dangerouslySetInnerHTML={{
                            __html: formatMarkdown(msg.text),
                          }}
                        />
                      )
                    )}
                  </div>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
          </div>

          <div className="chat-input">
            <div className="chat-input-inner">
              {attachedFiles.length > 0 && (
                <div className="attached-files-preview show">
                  {attachedFiles.map((file, idx) => (
                    <div className="file-preview-item" key={idx}>
                      {file.type.startsWith("image/") ? (
                        <div className="file-preview-wrapper">
                          <img
                            src={URL.createObjectURL(file)}
                            alt={file.name}
                            className="file-thumb"
                          />
                          <span className="file-name-label">{file.name}</span>
                        </div>
                      ) : (
                        <span>📎 {file.name}</span>
                      )}
                      <button
                        className="remove-file-btn"
                        onClick={() =>
                          setAttachedFiles(attachedFiles.filter((_, i) => i !== idx))
                        }
                      >
                        ❌
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <textarea
                className="chat-input-field"
                rows={1}
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleFileUploadWithInput();
                  }
                }}
                placeholder="Type your message..."
              />

              <div className="chat-bottom-bar">
              <label htmlFor="file-upload" className="file-upload-label" title="Attach file">📎</label>

                <input
                  id="file-upload"
                  type="file"
                  accept=".pdf,.docx,.png,.jpg,.jpeg,.zip"
                  multiple
                  className="file-upload-input"
                  onChange={handleFileInput}
                />
                <button
                  className="chat-send-button"
                  onClick={handleFileUploadWithInput}
                >
                  {t.send}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

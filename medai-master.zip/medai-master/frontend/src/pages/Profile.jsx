import React from "react";
import ProfileTabs from "../components/Profile/ProfileTabs";
// import Sidebar from "../components/dashboard/Sidebar";

const Profile = () => {
  return (
    <div className="profile-wrapper">
      {/* <Sidebar /> */}
      <ProfileTabs />
    </div>
  );
};

export default Profile;

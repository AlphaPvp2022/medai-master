import React, { useState } from "react";
import Navbar from "../components/homepage/Navbar";
import HeroSection from "../components/homepage/HeroSection";
import FAQSection from "../components/homepage/FAQ";
import Footer from "../components/homepage/Footer";
import AuthModal from "../components/authentication/AuthModel"; // Import Auth Modal
import "../styles/main_page/mainpage.css";

const MainPage = () => {
  const [showModal, setShowModal] = useState(false);

  const openRegisterModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  return (
    <div>
      <Navbar />
      <HeroSection/>

      {/* Services Section */}
      <section id="services" className="features">
        <h2>Цель MedAI</h2>
        <p>Создание полноценной замены врачу в задачах: первичного анализа, интерпретации данных и формирования решений.
        Система не направляет к врачу. Она предназначена для ситуаций, в которых пациент хочет получить понятный, логичный, клинически обоснованный ответ — без очередей и человеческого фактора.</p>

        <div className="feature-grid">
          <div className="feature-card">
            <span className="feature-icon">📄</span>
            <h3>Обработка документов</h3>
            <p>
              Загрузка PDF, фото, сканов и Word-документов. Распознавание диагнозов, назначений и анализов. Классификация информации по клинической значимости, включая неформатированные и частично читаемые документы.
            </p>
          </div>

          <div className="feature-card">
            <span className="feature-icon">🧠</span>
            <h3>Анализ жалоб и анамнеза</h3>
            <p>
              Ввод симптомов в свободной форме с автоматическим определением клинически значимых признаков. Связь текущих жалоб с историей болезни и построение персонализированной модели состояния.
            </p>
          </div>

          <div className="feature-card">
            <span className="feature-icon">📈</span>
            <h3>Заключения и рекомендации</h3>
            <p>
              Вычисление возможных состояний, расчёт рисков и приоритетов. Система предлагает конкретные рекомендации по анализам, мониторингу и образу жизни — без необходимости обращаться к врачу.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection />

      {/* Contact Section */}
      <Footer />

      {/* Registration Modal */}
      <AuthModal show={showModal} handleClose={closeModal} mode="register" />
    </div>
  );
};

export default MainPage;

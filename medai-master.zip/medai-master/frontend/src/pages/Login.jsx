import React from "react";
import { Link } from "react-router-dom";
import LoginForm from "../components/authentication/LoginForm";
import "../styles/auth/login.css";

const translations = {
  en: {
    welcome: "Welcome Back",
    description: "Log in to access your account and manage your medical records.",
    register1: 'Don’t have an account?',
    register2: "Register here",
  },
  ru: {
    welcome: "Добро пожаловать",
    description: "Войдите, чтобы получить доступ к своей учетной записи и управлять своими медицинскими записями.",
    register1: "Нет учетной записи?",
    register2: "Зарегистрируйтесь здесь"
  },
  uk: {
    welcome: "Ласкаво просимо",
    description: "Увійдіть, щоб отримати доступ до свого облікового запису та керувати своїми медичними записами.",
    register1: "У вас немає облікового запису?",
    register2: "Зареєструйтеся тут"
  },
};


function Login() {
  const lang = localStorage.getItem("language") || "en";
  const t = translations[lang];

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-content">
          <h1 className="auth-title">{t.welcome}</h1>
          <p className="auth-description">
            {t.description}<br />
            {t.register1} <Link to="/register/">{t.register2}</Link>
          </p>
        </div>
        <div className="auth-form-container">
          <div className="auth-card">
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;

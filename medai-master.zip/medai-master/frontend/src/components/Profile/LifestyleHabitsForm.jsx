import React, { useEffect, useState } from "react";
import axios from "axios";
import { getAccessToken } from "../../hooks/user.actions";

// Translations for LifestyleHabitsForm
const translations = {
  uk: {
    title: "🚶 Звички",
    smoking: "Курите?",
    alcohol: "Вживаєте алкоголь?",
    psychoactive: "Психоактивні речовини?",
    sport: "Займаєтеся спортом?",
    stress: "Рівень стресу:",
    sleep: "Якість сну:",
    saving: "Збереження...",
    saved: "✔ Збережено",
    error: "❌ Помилка при збереженні",
    activity: "Вид активності",
    frequency: "Скільки разів на тиждень?",
    duration: "Тривалість одного заняття (хвилин)",
    delete: "Видалити",
    add: "Додати",
    cancel: "Скасувати",
    usage: "Що використовуєте?",
    cigarettes: "Сигарети",
    vape: "Вейп",
    nicotine_patch: "Пластирі",
    other: "Інше",
    cigarettesPerDay: "Сигарет в день",
    smokingYears: "Стаж (років)",
    specifyOther: "Уточніть інше:",
    smokingFrequency: "Як часто ви курите?",
    daysPerWeek: "Днів на тиждень",
    litersPerWeek: "Літрів на тиждень",
    alcoholType: "Тип алкоголю",
    exampleHookah: "наприклад: кальян",
    exampleDaily: "наприклад: щодня",
    defineProblem: "уточніть проблему",
    minutes: "хвилин",
    save: "Зберегти",
    low: "Низький",
    medium: "Середній",
    high: "Високий",
    yes: "Так",
    no: "Ні"
  },
  ru: {
    title: "🚶 Жизненные привычки",
    smoking: "Курите ли вы?",
    alcohol: "Употребляете алкоголь?",
    psychoactive: "Принимаете психоактивные вещества?",
    sport: "Занимаетесь спортом?",
    stress: "Уровень стресса:",
    sleep: "Качество сна:",
    saving: "Сохранение...",
    saved: "✔ Сохранено",
    error: "❌ Ошибка при сохранении",
    activity: "Вид активности",
    frequency: "Сколько раз в неделю?",
    duration: "Продолжительность одного занятия (минут)",
    delete: "Удалить",
    add: "Добавить",
    cancel: "Отменить",
    usage: "Что используете?",
    cigarettes: "Сигареты",
    vape: "Вейп",
    nicotine_patch: "Пластыри",
    other: "Другое",
    cigarettesPerDay: "Сигарет в день",
    smokingYears: "Стаж (лет)",
    specifyOther: "Уточните другое:",
    smokingFrequency: "Как часто вы курите?",
    daysPerWeek: "Дней в неделю",
    litersPerWeek: "Литров в неделю",
    alcoholType: "Тип алкоголя",
    exampleHookah: "например: кальян",
    exampleDaily: "например: ежедневно",
    defineProblem: "уточните проблему",
    minutes: "минут",
    save: "Сохранить",
    low: "Низкий",
    medium: "Средний",
    high: "Высокий",
    yes: "Да",
    no: "Нет"
  },
  en: {
    title: "🚶 Lifestyle Habits",
    smoking: "Do you smoke?",
    alcohol: "Do you consume alcohol?",
    psychoactive: "Do you use psychoactive substances?",
    sport: "Do you exercise?",
    stress: "Stress Level:",
    sleep: "Sleep Quality:",
    saving: "Saving...",
    saved: "✔ Saved",
    error: "❌ Error saving",
    activity: "Activity Type",
    frequency: "How many times per week?",
    duration: "Duration per session (min)",
    delete: "Delete",
    add: "Add",
    cancel: "Cancel",
    usage: "What do you use?",
    cigarettes: "Cigarettes",
    vape: "Vape",
    nicotine_patch: "Nicotine patch",
    other: "Other",
    cigarettesPerDay: "Cigarettes per day",
    smokingYears: "Smoking years",
    specifyOther: "Specify other:",
    smokingFrequency: "How often do you smoke?",
    daysPerWeek: "Days per week",
    litersPerWeek: "Liters per week",
    alcoholType: "Type of alcohol",
    exampleHookah: "e.g., hookah",
    exampleDaily: "e.g., daily",
    defineProblem: "Specify the problem",
    minutes: "minutes",
    save: "Save",
    low: "Low",
    medium: "Medium",
    high: "High",
    yes: "Yes",
    no: "No"
  }
};


const LifestyleHabitsForm = () => {
  const [data, setData] = useState({
    smoking: null,
    alcohol: null,
    psychoactive: "",
    exercise_enabled: "нет",
    exercise: [],
    sleep: "",
    stress_level: ""
  });
  const [status, setStatus] = useState(null);
  const [isAddingExercise, setIsAddingExercise] = useState(false);
  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang];
  const token = getAccessToken();

  const labelMap = {
    cigarettes: t.cigarettes,
    vape: t.vape,
    nicotine_patch: t.nicotine_patch,
    other: t.other
  };  

  useEffect(() => {
    if (!token) return;
    axios
      .get("http://localhost:8000/api/user/me/", {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then((res) => {
        const resData = res.data;

        setData({
          ...data,
          smoking: typeof resData.smoking === "object" && resData.smoking !== null ? resData.smoking : null,
          alcohol: typeof resData.alcohol === "object" && resData.alcohol !== null ? resData.alcohol : null,
          psychoactive: resData.psychoactive || "",
          exercise_enabled: typeof resData.exercise_enabled === "string" ? resData.exercise_enabled : "нет",
          exercise: Array.isArray(resData.exercise)
            ? resData.exercise.map((e) => ({ ...e, _edit: false }))
            : [],
          sleep: resData.sleep || "",
          stress_level: resData.stress_level || ""
        });
      })
      .catch((err) => console.error("❌ Failed to load profile", err));
  }, [token]);

  const handleChange = (field, value) => {
    const updated = { ...data, [field]: value };
    setData(updated);
    setStatus("saving");

    axios
      .patch(
        "http://localhost:8000/api/user/me/",
        {
          [field]: value
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      )
      .then(() => {
        setStatus("saved");
        if (field === "exercise") setIsAddingExercise(false);
      })
      .catch((err) => {
        setStatus("error");
        console.error("❌ Save failed:", err.response?.data || err.message);
      });
  };

  const handleExerciseChange = (index, key, value) => {
    const updated = [...data.exercise];
    updated[index] = { ...updated[index], [key]: value };
    handleChange("exercise", updated);
  };

  const addExercise = () => {
    const last = data.exercise[data.exercise.length - 1];
    const isEmptyList = !data.exercise.length;
    const isComplete =
      isEmptyList ||
      (last &&
        last.activity?.trim() &&
        last.frequency?.trim() &&
        last.duration?.toString().trim());

    if (!isComplete) {
      return;
    }

    setIsAddingExercise(true);
    handleChange("exercise", [
      ...data.exercise,
      { activity: "", frequency: "", duration: "" }
    ]);
  };

  const cancelNewExercise = () => {
    if (data.exercise.length > 0) {
      const updated = [...data.exercise];
      updated.pop();
      handleChange("exercise", updated);
    }
    setIsAddingExercise(false);
  };

  const removeExercise = (index) => {
    const updated = [...data.exercise];
    updated.splice(index, 1);
    handleChange("exercise", updated);
    setIsAddingExercise(false);
  };

  return (
    <div className="form-section">
      <h2>{t.title} </h2>

      {/* Курение */}
      <label>{t.smoking}</label>
      <div className="radio-group">
      {["no", "yes"].map((val) => (
          <label key={val}>
            <input
              type="radio"
              name="smoking_enabled"
              value={val}
              checked={val === "yes" ? data.smoking?.enabled : !data.smoking?.enabled}
              onChange={() =>
                handleChange(
                  "smoking",
                  val === "yes"
                    ? {
                        enabled: true, 
                        types: [],
                        cigarettes_per_day: "",
                        years: "",
                        frequency: "",
                        other_detail: ""
                      }
                    : null
                )
              }
            />
            {val === "yes" ? t.yes : t.no}
          </label>
        ))}
      </div>

      {data.smoking?.enabled && (
        <div className="smoking-details">
          <div className="full-width">
            <label>{t.usage}</label>
            <div className="smoking-options-grid">
              {["cigarettes", "vape", "nicotine_patch", "other"].map((type) => (
                <label key={type} className="checkbox-row">
                  <input
                    type="checkbox"
                    checked={Array.isArray(data.smoking?.types) && data.smoking.types.includes(type)}
                    onChange={(e) => {
                      const updated = e.target.checked
                        ? [...(data.smoking.types || []), type]
                        : (data.smoking.types || []).filter((t) => t !== type);
                      handleChange("smoking", {
                        ...data.smoking,
                        types: updated,
                        ...(type === "other" && !e.target.checked
                          ? { other_detail: "" }
                          : {})
                      });
                    }}
                  />
                  {labelMap[type]}
                </label>
              ))}
            </div>
          </div>

    {data.smoking.types?.includes("cigarettes") && (
      <div className="form-row">
        <div className="inline-label-input">
          <label>{t.cigarettesPerDay}</label>
          <input
            type="number"
            value={data.smoking.cigarettes_per_day}
            onChange={(e) =>
              handleChange("smoking", {
                ...data.smoking,
                cigarettes_per_day: e.target.value
              })
            }
          />
        </div>
        <div className="inline-label-input">
          <label>{t.smokingYears}</label>
          <input
            type="number"
            value={data.smoking.years}
            onChange={(e) =>
              handleChange("smoking", {
                ...data.smoking,
                years: e.target.value
              })
            }
          />
        </div>
      </div>
    )}

    {data.smoking.types?.includes("other") && (
      <div className="form-row">
        <div className="inline-label-input">
          <label>{t.specifyOther}</label>
          <input
            type="text"
            placeholder={t.exampleHookah}
            value={data.smoking.other_detail}
            onChange={(e) =>
              handleChange("smoking", {
                ...data.smoking,
                other_detail: e.target.value
              })
            }
          />
        </div>
      </div>
    )}

    <div className="form-row">
      <div className="inline-label-input">
        <label>{t.smokingFrequency}</label>
        <input
          type="text"
          placeholder={t.exampleDaily}
          value={data.smoking.frequency}
          onChange={(e) =>
            handleChange("smoking", {
              ...data.smoking,
              frequency: e.target.value
            })
          }
        />
      </div>
    </div>
  </div>)}


      {/* Алкоголь */}
      <label>{t.alcohol}</label>
      <div className="radio-group">
        {["no", "yes"].map((val) => (
          <label key={val}>
            <input
              type="radio"
              name="alcohol_enabled"
              value={val}
              checked={val === "yes" ? data.alcohol?.enabled : !data.alcohol?.enabled}
              onChange={() =>
                handleChange(
                  "alcohol",
                  val === "yes"
                    ? {
                        enabled: true,
                        days_per_week: "",
                        liters_per_week: "",
                        type: ""
                      }
                    : null
                )
              }
            />
            {val === "yes" ? t.yes : t.no}
          </label>
        ))}
      </div>

      {data.alcohol?.enabled && (
        <>
        <div className="form-row">
        <div className="inline-label-input">
          <label>{t.daysPerWeek}</label>
          <input
            type="number"
            value={data.alcohol.days_per_week}
            onChange={(e) =>
              handleChange("alcohol", {
                ...data.alcohol,
                days_per_week: e.target.value
              })
            }
          />
        </div>
        <div className="inline-label-input">
          <label>{t.litersPerWeek}</label>
          <input
            type="number"
            value={data.alcohol.liters_per_week}
            onChange={(e) =>
              handleChange("alcohol", {
                ...data.alcohol,
                liters_per_week: e.target.value
              })
            }
          />
        </div>
      </div>
      
      <div className="form-row">
        <div className="inline-label-input">
          <label>{t.alcoholType}</label>
          <input
            type="text"
            value={data.alcohol.type}
            onChange={(e) =>
              handleChange("alcohol", {
                ...data.alcohol,
                type: e.target.value
              })
            }
          />
        </div>
      </div>
      </>
      )}


      {/* Психоактивные */}
      <label>{t.psychoactive}</label>
        <div className="radio-group">
          {["no", "yes"].map((val) => (
            <label key={val}>
              <input
                type="radio"
                name="psychoactive"
                value={val}
                checked={val === "yes" ? data.psychoactive?.startsWith("yes") : !data.psychoactive}
                onChange={() =>
                  handleChange("psychoactive", val === "yes" ? "yes" : "")
                }
              />
              {val === "yes" ? t.yes : t.no}
            </label>
          ))}
        </div>

        {data.psychoactive?.startsWith("yes") && (
          <input
            type="text"
            placeholder={t.usage}
            value={data.psychoactive.split(":")[1]?.trim() || ""}
            onChange={(e) =>
              handleChange(
                "psychoactive",
                e.target.value ? `yes: ${e.target.value}` : "yes"
              )
            }
          />
        )}


      {/* Спорт */}
      <label>{t.sport}</label>
      <div className="radio-group">
        {["no", "yes"].map((val) => (
          <label key={val}>
            <input
              type="radio"
              name="exercise_enabled"
              value={val}
              checked={data.exercise_enabled === val}
              onChange={() => {
                handleChange("exercise_enabled", val);
                if (
                  val === "yes" &&
                  (!Array.isArray(data.exercise) || data.exercise.length === 0)
                ) {
                  handleChange("exercise", [
                    { activity: "", frequency: "", duration: "" }
                  ]);
                  setIsAddingExercise(true);
                } else if (val === "no") {
                  setIsAddingExercise(false);
                }
              }}
            />
            {val === "yes" ? t.yes : t.no}
          </label>
        ))}
      </div>


      {data.exercise_enabled === "yes" && Array.isArray(data.exercise) && (
      <>
        {data.exercise.map((entry, idx) => {
          const isComplete = entry.activity && entry.frequency && entry.duration;
          const showEdit = entry._edit || !isComplete;

          return (
            <div key={idx} className="exercise-details">
              {showEdit ? (
                <>
                  <div className="form-row">
                    <div className="inline-label-input">
                      <label>{t.activity}</label>
                      <input
                        type="text"
                        value={entry.activity}
                        onChange={(e) =>
                          handleExerciseChange(idx, "activity", e.target.value)
                        }
                      />
                    </div>
                    <div className="inline-label-input">
                      <label>{t.frequency}</label>
                      <input
                        type="text"
                        value={entry.frequency}
                        onChange={(e) =>
                          handleExerciseChange(idx, "frequency", e.target.value)
                        }
                      />
                    </div>
                    <div className="inline-label-input">
                      <label>{t.duration}</label>
                      <input
                        type="number"
                        min="0"
                        value={entry.duration || ""}
                        onChange={(e) =>
                          handleExerciseChange(idx, "duration", e.target.value)
                        }
                      />
                    </div>
                  </div>

                  <div className="exercise-button-row">
                    <button
                      type="button"
                      className="cancel-button"
                      onClick={() => removeExercise(idx)}
                    >
                      {t.delete}
                    </button>
                    {isComplete && (
                      <button
                        type="button"
                        onClick={() =>
                          handleExerciseChange(idx, "_edit", false)
                        }
                      >
                        {t.save}
                      </button>
                    )}
                  </div>
                </>
              ) : (
                <div className="exercise-summary-box">
                  <p>
                    <strong>{t.activity}:</strong> {entry.activity} |{" "}
                    <strong>{t.frequency}:</strong> {entry.frequency} |{" "}
                    <strong>{t.duration}:</strong> {entry.duration} {t.minutes}
                  </p>
                  <p className="saved-hint">{t.layoutSaved}</p>
                  <div className="exercise-button-row">
                    <button
                      type="button"
                      onClick={() =>
                        handleExerciseChange(idx, "_edit", true)
                      }
                    >
                      ✏️ {t.edit}
                    </button>
                    <button
                      type="button"
                      className="cancel-button"
                      onClick={() => removeExercise(idx)}
                    >
                      🗑 
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}

    <div className="exercise-button-row">
      {isAddingExercise && (
        <button
          className="cancel-button"
          type="button"
          onClick={cancelNewExercise}
        >
          {t.cancel}
        </button>
      )}
      <button
        type="button"
        onClick={addExercise}
        disabled={isAddingExercise}
      >
        {t.add}
      </button>
    </div>
  </>
)}

      {/* Стресс */}
      <label>{t.stress}</label>
      <div className="radio-group">
        {[t.low, t.medium, t.high].map((level) => (
          <label key={level}>
            <input
              type="radio"
              name="stress_level"
              value={level}
              checked={data.stress_level === level}
              onChange={(e) => handleChange("stress_level", e.target.value)}
            />
            {level}
          </label>
        ))}
      </div>

      {/* Сон */}
      <label>{t.sleep}</label>
      <div className="radio-group">
        {[t.low, t.medium, t.high].map((quality) => (
          <label key={quality}>
            <input
              type="radio"
              name="sleep"
              value={quality}
              checked={data.sleep?.startsWith(quality)}
              onChange={() => handleChange("sleep", quality)}
            />
            {quality}
          </label>
        ))}
      </div>
      {data.sleep?.startsWith(t.low) && (
        <input
          type="text"
          placeholder={t.defineProblem}
          value={data.sleep.includes(":") ? data.sleep.split(":")[1] : ""}
          onChange={(e) =>
            handleChange("sleep", `Плохое: ${e.target.value}`)
          }
        />
      )}

      {/* Status feedback */}
      {status === "saving" && <p className="saving">{t.saving}</p>}
      {status === "saved" && <p className="saved">{t.saved}</p>}
      {status === "error" && <p className="error">{t.error}</p>}
    </div>
  );
};

export default LifestyleHabitsForm;

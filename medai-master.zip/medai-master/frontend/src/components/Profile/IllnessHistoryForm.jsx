// TranslatedIllnessHistoryForm.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { getAccessToken } from "../../hooks/user.actions";

const translations = {
  uk: {
    title: "🩺 Історія хвороб",
    chronic: "Хронічні захворювання:",
    serious: "Серйозні захворювання:",
    infections: "Інфекції:",
    surgeries: "Операції / травми:",
    family: "👨‍👩‍👧‍👦 Сімейний анамнез (близькі родичі)",
    allergy: "Алергії:",
    meds: "Ліки:",
    supps: "БАДи та вітаміни:",
    tests: "📅 Обстеження та аналізи",
    saving: "Збереження...",
    saved: "✔ Збережено",
    error: "❌ Помилка при збереженні",
    name: "Назва",
    date: "Дата",
    result: "Результат",
    diabetes: "Цукровий діабет",
    heart: "Серцеві захворювання",
    cancer: "Онкологічні захворювання",
    thyroid: "Захворювання щитовидної залози",
    mental: "Психічні розлади",
    other: "Інше",
    who: "Хто саме?",
    diseaseName: "Назва захворювання",
    addTest: "Додати аналіз",

  },
  ru: {
    title: "🩺 История заболеваний",
    chronic: "Хронические заболевания:",
    serious: "Серьёзные ранее перенесенные заболевания:",
    infections: "Инфекционные заболевания:",
    surgeries: "Хирургические операции и травмы:",
    family: "👨‍👩‍👧‍👦 Семейный анамнез (ближайшие родственники)",
    allergy: "Аллергии:",
    meds: "Принимаемые лекарства:",
    supps: "Витамины и БАДы:",
    tests: "📅 Последние медицинские обследования",
    saving: "Сохранение...",
    saved: "✔ Сохранено",
    error: "❌ Ошибка при сохранении",
    name: "Название",
    date: "Дата",
    result: "Результат",
    diabetes: "Сахарный диабет",
    heart: "Заболевания сердца",
    cancer: "Онкологические заболевания",
    thyroid: "Заболевания щитовидной железы",
    mental: "Психические расстройства",
    other: "Другое",
    who: "Кто именно?",
    diseaseName: "Название заболевания",
    addTest: "Добавить анализ",
  },
  en: {
    title: "🩺 Illness History",
    chronic: "Chronic Diseases:",
    serious: "Serious Illnesses:",
    infections: "Infections:",
    surgeries: "Surgeries / Injuries:",
    family: "👨‍👩‍👧‍👦 Family History (Close Relatives)",
    allergy: "Allergies:",
    meds: "Medications:",
    supps: "Supplements:",
    tests: "📅 Medical Exams and Tests",
    saving: "Saving...",
    saved: "✔ Saved",
    error: "❌ Error saving",
    name: "Name",
    date: "Date",
    result: "Result",
    diabetes: "Diabetes",
    heart: "Heart Diseases",
    cancer: "Cancer",
    thyroid: "Thyroid Diseases",
    mental: "Mental Disorders",
    other: "Other",
    who: "Who?",
    diseaseName: "Disease",
    addTest: "Add Test",
  }
};

const IllnessHistoryForm = () => {
  const [data, setData] = useState({
    chronic_diseases: "",
    serious_diseases: "",
    infections: "",
    surgeries: "",
    family_history: {},
    allergy_history: "",
    medications: "",
    supplements: "",
    recent_tests: []
  });
  const [status, setStatus] = useState(null);
  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang];
  const token = getAccessToken();

  useEffect(() => {
    if (!token) return;
    axios
      .get("http://localhost:8000/api/user/me/", {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then((res) => setData(res.data))
      .catch((err) => console.error("❌ Failed to load profile", err));
  }, [token]);

  const handleChange = (field, value) => {
    const updated = { ...data, [field]: value };
    setData(updated);
    setStatus("saving");
    axios
      .patch(
        "http://localhost:8000/api/user/me/",
        { [field]: value },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then(() => setStatus("saved"))
      .catch((err) => {
        setStatus("error");
        console.error("❌ Save failed:", err.response?.data || err.message);
      });
  };

  const updateTest = (index, field, value) => {
    const updatedTests = [...(data.recent_tests || [])];
    updatedTests[index] = { ...updatedTests[index], [field]: value };
    handleChange("recent_tests", updatedTests);
  };

  const addTest = () => {
    handleChange("recent_tests", [...(data.recent_tests || []), { name: "", date: "", result: "" }]);
  };

  const removeTest = (index) => {
    const updated = [...(data.recent_tests || [])];
    updated.splice(index, 1);
    handleChange("recent_tests", updated);
  };

  return (
    <div className="form-section">
  <h2>{t.title}</h2>

  {[
  { key: "diabetes", label: t.diabetes },
  { key: "heart", label: t.heart },
  { key: "cancer", label: t.cancer },
  { key: "thyroid", label: t.thyroid },
  { key: "mental", label: t.mental },
  { key: "other", label: t.other }
].map(({ key, label }) => (
  <div key={key} className="family-condition-block">
    <div className="family-row">
      <div className="label-side">
        {label}
        {data.family_history?.[key]?.enabled && key !== "other" && (
          <input
            type="text"
            className="who-field"
            placeholder={t.who}
            value={data.family_history[key].who}
            onChange={(e) =>
              handleChange("family_history", {
                ...data.family_history,
                [key]: {
                  ...data.family_history[key],
                  who: e.target.value
                }
              })
            }
          />
        )}
        {data.family_history?.[key]?.enabled && key === "other" && (
          <div className="other-fields">
            <input
              type="text"
              placeholder={t.diseaseName}
              value={data.family_history[key].condition}
              onChange={(e) =>
                handleChange("family_history", {
                  ...data.family_history,
                  [key]: {
                    ...data.family_history[key],
                    condition: e.target.value
                  }
                })
              }
            />
            <input
              type="text"
              placeholder={t.who}
              value={data.family_history[key].who}
              onChange={(e) =>
                handleChange("family_history", {
                  ...data.family_history,
                  [key]: {
                    ...data.family_history[key],
                    who: e.target.value
                  }
                })
              }
            />
          </div>
        )}
      </div>

      <input
        type="checkbox"
        checked={data.family_history?.[key]?.enabled || false}
        onChange={(e) =>
          handleChange("family_history", {
            ...data.family_history,
            [key]: {
              enabled: e.target.checked,
              who: data.family_history?.[key]?.who || "",
              condition: data.family_history?.[key]?.condition || ""
            }
          })
        }
      />
    </div>
  </div>
))}



  <div className="form-row">
    <label>{t.allergy}</label>
    <textarea value={data.allergy_history} onChange={(e) => handleChange("allergy_history", e.target.value)} />
  </div>

  <div className="form-row">
    <label>{t.meds}</label>
    <textarea value={data.medications} onChange={(e) => handleChange("medications", e.target.value)} />
  </div>

  <div className="form-row">
    <label>{t.supps}</label>
    <textarea value={data.supplements} onChange={(e) => handleChange("supplements", e.target.value)} />
  </div>

  <label>{t.tests}</label>
  <div className="tests-container">
    {(data.recent_tests || []).map((test, idx) => (
      <div key={idx} className="recent-test-card">
        <input
          type="text"
          placeholder={t.name}
          value={test.name}
          onChange={(e) => updateTest(idx, "name", e.target.value)}
        />
        <input
          type="date"
          value={test.date}
          onChange={(e) => updateTest(idx, "date", e.target.value)}
        />
        <input
          type="text"
          placeholder={t.result}
          value={test.result}
          onChange={(e) => updateTest(idx, "result", e.target.value)}
        />
        <button type="button" onClick={() => removeTest(idx)}>✖</button>
      </div>
    ))}
    <button type="button" className="add-test-btn" onClick={addTest}>{t.addTest}</button>
  </div>

  {status === "saving" && <p className="saving">{t.saving}</p>}
  {status === "saved" && <p className="saved">{t.saved}</p>}
  {status === "error" && <p className="error">{t.error}</p>}
</div>

  );
};

export default IllnessHistoryForm;

// TranslatedCurrentConditionForm.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import { getAccessToken } from "../../hooks/user.actions";

const translations = {
  uk: {
    title: "🩺 Поточний стан",
    symptoms: "Скарги та симптоми:",
    tests: "Результати аналізів / обстежень:",
    notes: "Додаткові відомості:",
    saving: "Збереження...",
    saved: "✔ Збережено",
    error: "❌ Помилка при збереженні"
  },
  ru: {
    title: "🩺 Текущее состояние",
    symptoms: "Жалобы и симптомы:",
    tests: "Результаты анализов / обследований:",
    notes: "Дополнительные сведения:",
    saving: "Сохранение...",
    saved: "✔ Сохранено",
    error: "❌ Ошибка при сохранении"
  },
  en: {
    title: "🩺 Current Condition",
    symptoms: "Symptoms:",
    tests: "Recent Test Results:",
    notes: "Additional Notes:",
    saving: "Saving...",
    saved: "✔ Saved",
    error: "❌ Error saving"
  }
};

const CurrentConditionForm = () => {
  const [data, setData] = useState({
    symptoms: "",
    recent_tests: "",
    additional_notes: ""
  });
  const [status, setStatus] = useState(null);
  const token = getAccessToken();
  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang];

  useEffect(() => {
    if (!token) return;
    axios
      .get("http://localhost:8000/api/user/me/", {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then((res) => setData(res.data))
      .catch((err) => console.error("❌ Failed to load profile", err));
  }, [token]);

  const handleChange = (field, value) => {
    const updated = { ...data, [field]: value };
    setData(updated);
    setStatus("saving");
    axios
      .patch(
        "http://localhost:8000/api/user/me/",
        { [field]: value },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      .then(() => setStatus("saved"))
      .catch((err) => {
        setStatus("error");
        console.error("❌ Save failed:", err.response?.data || err.message);
      });
  };

  return (
    <div className="form-section">
      <h2>{t.title}</h2>

      <label>{t.symptoms}</label>
      <textarea
        value={data.symptoms}
        onChange={(e) => handleChange("symptoms", e.target.value)}
      />

      <label>{t.tests}</label>
      <textarea
        value={data.recent_tests}
        onChange={(e) => handleChange("recent_tests", e.target.value)}
      />

      <label>{t.notes}</label>
      <textarea
        value={data.additional_notes}
        onChange={(e) => handleChange("additional_notes", e.target.value)}
      />

      {status === "saving" && <p className="saving">{t.saving}</p>}
      {status === "saved" && <p className="saved">{t.saved}</p>}
      {status === "error" && <p className="error">{t.error}</p>}
    </div>
  );
};

export default CurrentConditionForm;
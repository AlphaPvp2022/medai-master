import React, { useEffect, useState } from "react";
import PersonalInfoForm from "./PersonalInfoForm";
import IllnessHistoryForm from "./IllnessHistoryForm";
import LifestyleHabitsForm from "./LifestyleHabitsForm";
import CurrentConditionForm from "./CurrentConditionForm";
import Sidebar from "../dashboard/Sidebar";
import api from "../../helpers/axios";
import "../../styles/profile_info/profile.css";
import { useNavigate } from "react-router-dom";

const translations = {
  uk: ["Загальна Інформація", "Історія Хвороб", "Звички", "Поточний стан"],
  ru: ["Общая Информация", "История Болезней", "Привычки", "Текущее состояние"],
  en: ["General Info", "Illness History", "Habits", "Current Condition"]
};

const ProfileTabs = () => {
  const [activeTab, setActiveTab] = useState("personal");
  const [sessions, setSessions] = useState([]);
  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang] || translations.uk;
  const navigate = useNavigate(); 

  useEffect(() => {
    const fetchChatSessions = async () => {
      try {
        const res = await api.get("/chat/sessions/");
        setSessions(res.data);
      } catch (err) {
        console.error("Failed to fetch chat sessions", err);
      }
    };
    fetchChatSessions();
  }, []);

  const tabs = [
    { key: "personal", label: t[0] },
    { key: "illness", label: t[1] },
    { key: "lifestyle", label: t[2] },
    { key: "condition", label: t[3] }
  ];

  const renderTab = () => {
    switch (activeTab) {
      case "personal":
        return <PersonalInfoForm />;
      case "illness":
        return <IllnessHistoryForm />;
      case "lifestyle":
        return <LifestyleHabitsForm />;
      case "condition":
        return <CurrentConditionForm />;
      default:
        return null;
    }
  };

  return (
    <div className="chat-dashboard">
      <Sidebar
        sessions={sessions}
        onSelectChat={(chatId) => navigate(`/dashboard?chatId=${chatId}`)} // ✅ This line
        onNewChat={() => {}}
        onRenameChat={() => {}}
        onTogglePin={() => {}}
        onDeleteChat={() => {}}
      />
      <div className="chat-main">
        <div className="profile-tabs">
          <div className="tab-buttons">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={activeTab === tab.key ? "active" : ""}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <div className="tab-content">{renderTab()}</div>
        </div>
      </div>
    </div>
  );
};

export default ProfileTabs;

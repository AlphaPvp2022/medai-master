import React, { useEffect, useState } from "react";
import axios from "axios";
import { getAccessToken } from "../../hooks/user.actions";

const translations = {
  uk: {
    personalInfo: "👤 Личні дані",
    fullName: "ПІБ:",
    gender: "Стать:",
    birthDate: "Дата народження:",
    nationality: "Національність:",
    height: "Зріст (см):",
    weight: "Вага (кг):",
    history: "Загальний медичний анамнез:",
    location: "Місто / Село, Країна:",
    occupation: "Професія:",
    workplaceRisks: "Шкідливі фактори на роботі:",
    envRisks: "Екологічні шкідливості:",
    environment: "🏙️ Середовище проживання та професійна діяльність",
    saving: "Збереження...",
    saved: "✔ Збережено",
    error: "❌ Помилка при збереженні",
    genderOptions: [
      { value: "male", label: "чоловіча" },
      { value: "female", label: "жіноча" },
      { value: "other", label: "інше" }
    ]
  },
  ru: {
    personalInfo: "👤 Личные данные",
    fullName: "ФИО:",
    gender: "Пол:",
    birthDate: "Дата рождения:",
    nationality: "Национальность:",
    height: "Рост (см):",
    weight: "Вес (кг):",
    history: "Общий медицинский анамнез:",
    location: "Город / Село, Страна:",
    occupation: "Профессия:",
    workplaceRisks: "Вредные факторы на работе:",
    envRisks: "Экологические вредности:",
    environment: "🏙️ Среда проживания и профессиональная деятельность",
    saving: "Сохранение...",
    saved: "✔ Сохранено",
    error: "❌ Ошибка при сохранении",
    genderOptions: [
      { value: "male", label: "мужской" },
      { value: "female", label: "женский" },
      { value: "other", label: "другое" }
    ]
  },
  en: {
    personalInfo: "👤 Personal Information",
    fullName: "Full Name:",
    gender: "Gender:",
    birthDate: "Birth Date:",
    nationality: "Nationality:",
    height: "Height (cm):",
    weight: "Weight (kg):",
    history: "General Medical History:",
    location: "City / Village, Country:",
    occupation: "Occupation:",
    workplaceRisks: "Workplace Hazards:",
    envRisks: "Environmental Hazards:",
    environment: "🏙️ Living and Occupational Environment",
    saving: "Saving...",
    saved: "✔ Saved",
    error: "❌ Error saving",
    genderOptions: [
      { value: "male", label: "male" },
      { value: "female", label: "female" },
      { value: "other", label: "other" }
    ]
  }
};

const PersonalInfoForm = () => {
  const [data, setData] = useState({
    full_name: "",
    gender: "",
    birth_date: "",
    nationality: "",
    height_cm: "",
    weight_kg: "",
    general_history: "",
    location_type: "",
    occupation: "",
    workplace_risks: "",
    env_risks: ""
  });

  const [status, setStatus] = useState(null);

  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang];
  const token = getAccessToken();

  useEffect(() => {
    if (!token) return;

    axios
      .get("http://localhost:8000/api/user/me/", {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      .then((res) => setData(res.data))
      .catch((err) => console.error("❌ Failed to load profile", err));
  }, [token]);

  const handleChange = (field, value) => {
    const updated = { ...data, [field]: value };
    setData(updated);
    setStatus("saving");

    axios
      .patch(
        "http://localhost:8000/api/user/me/",
        { [field]: value },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )
      .then(() => setStatus("saved"))
      .catch((err) => {
        setStatus("error");
        console.error("❌ Save failed:", err.response?.data || err.message);
      });
  };

  return (
    <div className="form-section">
      <h2>{t.personalInfo}</h2>

      <div className="form-row">
        <label>{t.fullName}</label>
        <input
          type="text"
          value={data.full_name}
          onChange={(e) => handleChange("full_name", e.target.value)}
        />
      </div>

      <div className="form-row">
        <label>{t.gender}</label>
        <div className="radio-group">
        {t.genderOptions.map(({ value, label }) => (
          <label key={value}>
            <input
              type="radio"
              name="gender"
              value={value}
              checked={data.gender === value}
              onChange={() => handleChange("gender", value)}
            />
            {label}
          </label>
        ))}
        </div>
      </div>

      <div className="form-row">
        <label>{t.birthDate}</label>
        <input
          type="date"
          value={data.birth_date || ""}
          onChange={(e) => handleChange("birth_date", e.target.value)}
        />
      </div>

      <div className="form-row">
        <label>{t.nationality}</label>
        <input
          type="text"
          value={data.nationality}
          onChange={(e) => handleChange("nationality", e.target.value)}
        />
      </div>

      <div className="form-row">
        <label>{t.height}</label>
        <input
          type="number"
          value={data.height_cm}
          onChange={(e) => handleChange("height_cm", e.target.value)}
        />
      </div>

      <div className="form-row">
        <label>{t.weight}</label>
        <input
          type="number"
          value={data.weight_kg}
          onChange={(e) => handleChange("weight_kg", e.target.value)}
        />
      </div>

      <div className="form-row full-width">
        <label>{t.history}</label>
        <textarea
          rows={4}
          value={data.general_history}
          onChange={(e) => handleChange("general_history", e.target.value)}
        />
      </div>

      <h2>{t.environment}</h2>

      <div className="form-row">
        <label>{t.location}</label>
        <input
          type="text"
          value={data.location_type}
          onChange={(e) => handleChange("location_type", e.target.value)}
          placeholder="e.g., Berlin, Germany"
        />
      </div>

      <div className="form-row full-width">
        <label>{t.occupation}</label>
        <textarea
          value={data.occupation}
          onChange={(e) => handleChange("occupation", e.target.value)}
          placeholder="e.g., teacher, programmer"
        />
      </div>

      <div className="form-row full-width">
        <label>{t.workplaceRisks}</label>
        <textarea
          value={data.workplace_risks}
          onChange={(e) => handleChange("workplace_risks", e.target.value)}
          placeholder="e.g., chemical exposure, heavy labor"
        />
      </div>

      <div className="form-row full-width">
        <label>{t.envRisks}</label>
        <textarea
          value={data.env_risks}
          onChange={(e) => handleChange("env_risks", e.target.value)}
          placeholder="e.g., nearby industrial pollution"
        />
      </div>

      {status === "saving" && <p className="saving">{t.saving}</p>}
      {status === "saved" && <p className="saved">{t.saved}</p>}
      {status === "error" && <p className="error">{t.error}</p>}
    </div>
  );
};

export default PersonalInfoForm;

import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Menu,
  User2,
  LogOut,
  MessageSquareText,
  Plus,
  Pencil,
  Pin,
  PinOff,
  Check,
  Trash2,
  Globe,
} from "lucide-react";
import "../../styles/sidebar.css";
import LanguageSelector from "./LanguageSelector";
import api from "../../helpers/axios";

const translations = {
  uk: {
    chat: "Чат",
    profile: "Мій профіль",
    language: "Українська",
    quickAccess: "Швидкий доступ",
    logout: "Вийти",
    newChat: "Новий чат",
    pinnedChats: "Закріплені чати",
    chatHistory: "Історія чатів",
    noChats: "Немає чатів. Створіть новий!",
    noHistory: "Немає доступних чатів"
  },
  ru: {
    chat: "Чат",
    profile: "Мой профиль",
    language: "Русский",
    quickAccess: "Быстрый доступ",
    logout: "Выйти",
    newChat: "Новый чат",
    pinnedChats: "Закрепленные чаты",
    chatHistory: "История чатов",
    noChats: "Чатов нет. Начните новый!",
    noHistory: "Нет доступных чатов"
  },
  en: {
    chat: "Chat",
    profile: "My Profile",
    language: "English",
    quickAccess: "Quick Access",
    logout: "Logout",
    newChat: "New Chat",
    pinnedChats: "Pinned Chats",
    chatHistory: "Chat History",
    noChats: "No chats yet. Start a new one!",
    noHistory: "No available chats"
  }
};

const Sidebar = ({
  sessions = [],
  setSessions = () => {},
  currentChatId,
  setCurrentChatId = () => {},
  onNewChat = () => {},
  onSelectChat = () => {},
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [renameValue, setRenameValue] = useState("");
  const [showLanguageModal, setShowLanguageModal] = useState(false);

  const lang = localStorage.getItem("language") || "uk";
  const t = translations[lang];

  const toggleMobile = () => setMobileOpen((prev) => !prev);

  const handleDeleteChat = async (chatId) => {
    try {
      await api.delete(`/chat/delete/${chatId}/`);
      setSessions((prev) => prev.filter((s) => s.id !== chatId));
      if (currentChatId === chatId) setCurrentChatId(null);
    } catch (err) {
      console.error("Failed to delete chat:", err);
    }
  };

  const handleTogglePin = async (chatId) => {
    try {
      await api.post(`/chat/pin/${chatId}/`);
      setSessions((prev) =>
        prev.map((s) =>
          s.id === chatId ? { ...s, pinned: !s.pinned } : s
        )
      );
    } catch (err) {
      console.error("Failed to toggle pin:", err);
    }
  };

  const handleRename = async (id, newTitle) => {
    try {
      const chat = sessions.find((s) => s.id === id);
      const updated = { ...chat, title: newTitle };
      await api.patch(`/chat/sessions/${id}/`, { title: newTitle });
      setSessions((prev) =>
        prev.map((s) => (s.id === id ? updated : s))
      );
    } catch (err) {
      console.error("Rename failed", err);
    }
  };

  const saveRename = (id) => {
    if (renameValue.trim()) {
      handleRename(id, renameValue.trim());
    }
    setEditingId(null);
  };

  const renderChat = (chat) => {
    const isPlaceholder = !chat.title || chat.title.toLowerCase().startsWith("new chat");

    return (
      <li
        key={chat.id}
        className={`chat-history-item ${chat.pinned ? "pinned" : ""} ${chat.id === currentChatId ? "active" : ""}`}
      >
        {editingId === chat.id ? (
          <div className="chat-rename">
            <input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && saveRename(chat.id)}
              autoFocus
            />
            <button onClick={() => saveRename(chat.id)}>
              <Check size={14} />
            </button>
          </div>
        ) : (
          <div className="chat-title" onClick={() => { onSelectChat(chat.id); setMobileOpen(false); }}>
            <span>{isPlaceholder ? t.newChat : chat.title}</span>
            <div className="chat-controls">
              <button onClick={(e) => { e.stopPropagation(); setEditingId(chat.id); setRenameValue(chat.title || t.newChat); }}>
                <Pencil size={14} />
              </button>
              <button onClick={(e) => { e.stopPropagation(); handleTogglePin(chat.id); }}>
                {chat.pinned ? <PinOff size={14} /> : <Pin size={14} />}
              </button>
              <button onClick={(e) => { e.stopPropagation(); handleDeleteChat(chat.id); }}>
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        )}
      </li>
    );
  };

  return (
    <>
      <button className="icon-button toggle-button mobile-toggle" onClick={toggleMobile}>
        <Menu size={20} />
      </button>

      <div className={`sidebar ${(mobileOpen ? "open" : collapsed ? "collapsed" : "")}`}>
        <div className="sidebar-toggle-wrapper desktop-only">
          <button className="icon-button toggle-button" onClick={() => setCollapsed(!collapsed)}>
            <Menu size={18} />
          </button>
        </div>

        <div className="new-chat">
          <button className="new-chat-button" onClick={() => { onNewChat(); setMobileOpen(false); }}>
            <Plus size={16} /> {!collapsed && t.newChat}
          </button>
        </div>

        <div className="chat-groupings">
          {sessions.length === 0 ? (
            <>
              <div className="no-chats">{t.noChats}</div>
              <h4 className="sidebar-section-title">{t.chatHistory}</h4>
            </>
          ) : (
            <>
              {sessions.some((s) => s.pinned === true) && (
                <>
                  <h4 className="sidebar-section-title">{t.pinnedChats}</h4>
                  <ul className="chat-history-list">
                    {sessions.filter((s) => s.pinned === true).map(renderChat)}
                  </ul>
                </>
              )}
              <h4 className="sidebar-section-title">{t.chatHistory}</h4>
              <ul className="chat-history-list">
                {sessions.filter((s) => !s.pinned).map(renderChat)}
              </ul>
            </>
          )}
        </div>

        <div className="sidebar-section">
          <h4 className="sidebar-section-title">{t.quickAccess}</h4>
          <div className="sidebar-links">
            <Link to="/dashboard" onClick={() => setMobileOpen(false)}>
              <MessageSquareText size={18} />
              <span>{t.chat}</span>
            </Link>
            <Link to="/profile" onClick={() => setMobileOpen(false)}>
              <User2 size={18} />
              <span>{t.profile}</span>
            </Link>
            <button className="sidebar-link-button" onClick={() => setShowLanguageModal(true)}>
              <Globe size={18} />
              <span>{t.language}</span>
            </button>
          </div>
        </div>

        <div className="sidebar-footer">
          <button className="logout-button">
            <LogOut size={16} /> <span>{t.logout}</span>
          </button>
        </div>

        {showLanguageModal && (
          <LanguageSelector
            onSelect={async (lang) => {
              localStorage.setItem("language", lang);
              try {
                await api.post("/profile/set-language/", { language: lang });
              } catch (err) {
                console.error("Failed to update language", err);
              }
              setShowLanguageModal(false);
              window.location.reload();
            }}
            onClose={() => setShowLanguageModal(false)}
          />
        )}
      </div>
    </>
  );
};

export default Sidebar;

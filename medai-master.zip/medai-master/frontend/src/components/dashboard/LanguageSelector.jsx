// src/components/dashboard/LanguageSelector.jsx
import React from "react";
import "../../styles/dashboard/language_selector.css";

const headings = {
    uk: "Оберіть мову",
    ru: "Выберите язык",
    en: "Select Language",
  };
  
  const LanguageSelector = ({ onSelect, onClose }) => {
    const currentLang = localStorage.getItem("language") || "uk";
    const title = headings[currentLang] || headings.uk;

    console.log('Current language:', currentLang)
  
    return (
      <div className="language-modal">
        <div className="language-modal-content">
          <h3>{title}</h3>
          <div className="language-buttons">
            <button onClick={() => onSelect("uk")}>Українська</button>
            <button onClick={() => onSelect("ru")}>Русский</button>
            <button onClick={() => onSelect("en")}>English</button>
          </div>
          <button className="language-close" onClick={onClose}>✕</button>
        </div>
      </div>
    );
  };
  
  export default LanguageSelector;

import React, { useEffect, useState } from "react";
import api from "../helpers/axios"; // ✅ Use centralized Axios instance
import "../styles/dashboard/customer_info.css";

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);

  // User Inputs
  const [accountNumber, setAccountNumber] = useState("");
  const [serviceAddress, setServiceAddress] = useState("");
  const [livingUnits, setLivingUnits] = useState(1);
  const [meters, setMeters] = useState([]); // Existing meters
  const [newMeters, setNewMeters] = useState([{ meterNumber: "", meterType: "", meterSize: "" }]);

  const [step, setStep] = useState(1); // Tracks the progress of the form

  // ✅ Fetch Profile Data on Mount
  useEffect(() => {
    api.get("/customers/profile/")
      .then((response) => setProfile(response.data))
      .catch(() => setError("Failed to load profile. Please try again."));
  }, []);

  // ✅ Check if Account Exists
  const checkAccount = () => {
    api.get(`/customers/accounts/${accountNumber}/service-addresses/`)
      .then((response) => {
        const data = response.data;
        if (data.length > 0) {
          const serviceData = data[0];
          setServiceAddress(serviceData.address);
          setLivingUnits(serviceData.living_units);
          
          // ✅ Fetch meters for this service address
          api.get(`/customers/service-addresses/${serviceData.id}/meters/`)
            .then((res) => {
              setMeters(res.data);
              setStep(4); // Show meters section
            })
            .catch(() => setError("Error fetching meters."));
        } else {
          setMeters([]);
          setStep(3); // No meters found, allow new meter input
        }
      })
      .catch(() => setError("Account not found. Please enter details."));
  };

  // ✅ Handle Adding a New Account
  const handleAddAccount = () => {
    api.post("/customers/accounts/", { account_number: accountNumber })
      .then(() => {
        setProfile({ ...profile, accounts: [...(profile?.accounts || []), { account_number: accountNumber }] });
        setStep(2); // Move to the next step
      })
      .catch(() => setError("Failed to add account."));
  };

  // ✅ Handle Adding a New Meter
  const handleAddMeter = () => {
    if (!serviceAddress) return;
    newMeters.forEach((meter) => {
      api.post("/customers/meters/", { 
        service_address: serviceAddress,
        meter_number: meter.meterNumber,
        meter_type: meter.meterType,
        meter_size: meter.meterSize
      })
        .then((response) => setMeters([...meters, response.data]))
        .catch(() => setError("Failed to add meter."));
    });
    setNewMeters([{ meterNumber: "", meterType: "", meterSize: "" }]); // Reset input fields
  };

  // ✅ Add more meter fields dynamically
  const addMeterField = () => {
    setNewMeters([...newMeters, { meterNumber: "", meterType: "", meterSize: "" }]);
  };

  if (!profile) return <p>Loading...</p>;

  return (
    <div className="profile-container">
      <h2>Profile Information</h2>
      {error && <p className="error-message">{error}</p>}

      <div className="profile-section">
        <p><strong>First Name:</strong> {profile.first_name}</p>
        <p><strong>Last Name:</strong> {profile.last_name}</p>
      </div>

      {/* Step 1: Add Account */}
      {step >= 1 && (
        <div className="add-section">
          <h4>Add Account</h4>
          <input 
            type="text" 
            placeholder="New Account Number" 
            value={accountNumber} 
            onChange={(e) => setAccountNumber(e.target.value)} 
          />
          <button onClick={handleAddAccount}>Add Account</button>
        </div>
      )}

      {/* Step 2: Add Service Address & Living Units */}
      {step >= 2 && (
        <div className="add-section">
          <h4>Add Service Address</h4>
          <input 
            type="text" 
            placeholder="Service Address" 
            value={serviceAddress} 
            onChange={(e) => setServiceAddress(e.target.value)} 
          />
          <input 
            type="number" 
            placeholder="Living Units" 
            value={livingUnits} 
            onChange={(e) => setLivingUnits(e.target.value)} 
          />
          <button onClick={checkAccount}>Check Account</button>
        </div>
      )}

      {/* Step 3 & 4: Show Existing Meters or Add New Meters */}
      {step >= 3 && (
        <div className="meters-section">
          <h4>Meters</h4>
          {meters.length > 0 ? (
            meters.map((meter) => (
              <p key={meter.meter_number}>
                {meter.meter_number} ({meter.meter_type}, {meter.meter_size})
              </p>
            ))
          ) : (
            <>
              <h5>Add New Meter</h5>
              {newMeters.map((meter, index) => (
                <div key={index} className="meter-inputs">
                  <input 
                    type="text" 
                    placeholder="Meter Number" 
                    value={meter.meterNumber} 
                    onChange={(e) => {
                      const updatedMeters = [...newMeters];
                      updatedMeters[index].meterNumber = e.target.value;
                      setNewMeters(updatedMeters);
                    }} 
                  />
                  <input 
                    type="text" 
                    placeholder="Meter Type" 
                    value={meter.meterType} 
                    onChange={(e) => {
                      const updatedMeters = [...newMeters];
                      updatedMeters[index].meterType = e.target.value;
                      setNewMeters(updatedMeters);
                    }} 
                  />
                  <input 
                    type="text" 
                    placeholder="Meter Size" 
                    value={meter.meterSize} 
                    onChange={(e) => {
                      const updatedMeters = [...newMeters];
                      updatedMeters[index].meterSize = e.target.value;
                      setNewMeters(updatedMeters);
                    }} 
                  />
                </div>
              ))}
              <button onClick={handleAddMeter}>Add Meter</button>
              <button onClick={addMeterField}>Add Another Meter</button>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default Profile;

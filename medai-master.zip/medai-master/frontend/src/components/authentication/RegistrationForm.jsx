import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const translations = {
  en: {
    firstName: "First Name",
    lastName: "Last Name",
    username: "Username",
    email: "Email Address",
    password: "Password",
    placeholders: {
      firstName: "Enter first name",
      lastName: "Enter last name",
      username: "Enter username",
      email: "Enter email",
      password: "Password",
    },
    invalid: {
      firstName: "First name is required.",
      lastName: "Last name is required.",
      username: "Username is required.",
      email: "Please provide a valid email.",
      password: "Password must be at least 8 characters.",
    },
    submit: "Register",
  },
  ru: {
    firstName: "Имя",
    lastName: "Фамилия",
    username: "Имя пользователя",
    email: "Электронная почта",
    password: "Пароль",
    placeholders: {
      firstName: "Введите имя",
      lastName: "Введите фамилию",
      username: "Введите имя пользователя",
      email: "Введите email",
      password: "Пароль",
    },
    invalid: {
      firstName: "Имя обязательно.",
      lastName: "Фамилия обязательна.",
      username: "Имя пользователя обязательно.",
      email: "Пожалуйста, введите корректный email.",
      password: "Пароль должен содержать минимум 8 символов.",
    },
    submit: "Зарегистрироваться",
  },
  uk: {
    firstName: "Ім’я",
    lastName: "Прізвище",
    username: "Ім’я користувача",
    email: "Електронна пошта",
    password: "Пароль",
    placeholders: {
      firstName: "Введіть ім’я",
      lastName: "Введіть прізвище",
      username: "Введіть ім’я користувача",
      email: "Введіть email",
      password: "Пароль",
    },
    invalid: {
      firstName: "Ім’я обов’язкове.",
      lastName: "Прізвище обов’язкове.",
      username: "Ім’я користувача обов’язкове.",
      email: "Будь ласка, введіть дійсний email.",
      password: "Пароль має бути не менше 8 символів.",
    },
    submit: "Зареєструватися",
  },
};

function RegistrationForm() {
  const lang = localStorage.getItem("language") || "en";
  const t = translations[lang];

  const navigate = useNavigate();
  const [validated, setValidated] = useState(false);
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    first_name: "",
    last_name: "",
    bio: "",
  });
  const [error, setError] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const registrationForm = event.currentTarget;

    if (registrationForm.checkValidity() === false) {
      event.stopPropagation();
      setValidated(true);
      return;
    }

    setValidated(true);

    const data = {
      username: form.username,
      password: form.password,
      email: form.email,
      first_name: form.first_name,
      last_name: form.last_name,
      bio: form.bio,
    };

    try {
      const res = await axios.post("http://localhost:8000/api/auth/register/", data);

      if (res.data.access) {
        localStorage.setItem("auth", JSON.stringify({
          access: res.data.access,
          refresh: res.data.refresh,
          user: res.data.user,
        }));
        localStorage.setItem("token", res.data.access);

        await fetch("http://localhost:8000/api/profile/set-language/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${res.data.access}`,
          },
          body: JSON.stringify({ language: lang }),
        });

        navigate("/dashboard");
      } else {
        setError("Registration succeeded but no access token was returned.");
      }
    } catch (err) {
      const message =
        err.response?.data?.error ||
        err.response?.data?.detail ||
        "Registration failed. Please check your input.";
      setError(message);
    }
  };

  return (
    <Form
      id="registration-form"
      className="auth-form"
      noValidate
      validated={validated}
      onSubmit={handleSubmit}
    >
      <Form.Group className="mb-3">
        <Form.Label>{t.firstName}</Form.Label>
        <Form.Control
          value={form.first_name}
          onChange={(e) => setForm({ ...form, first_name: e.target.value })}
          required
          type="text"
          placeholder={t.placeholders.firstName}
        />
        <Form.Control.Feedback type="invalid">
          {t.invalid.firstName}
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>{t.lastName}</Form.Label>
        <Form.Control
          value={form.last_name}
          onChange={(e) => setForm({ ...form, last_name: e.target.value })}
          required
          type="text"
          placeholder={t.placeholders.lastName}
        />
        <Form.Control.Feedback type="invalid">
          {t.invalid.lastName}
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>{t.username}</Form.Label>
        <Form.Control
          value={form.username}
          onChange={(e) => setForm({ ...form, username: e.target.value })}
          required
          type="text"
          placeholder={t.placeholders.username}
        />
        <Form.Control.Feedback type="invalid">
          {t.invalid.username}
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>{t.email}</Form.Label>
        <Form.Control
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
          type="email"
          placeholder={t.placeholders.email}
        />
        <Form.Control.Feedback type="invalid">
          {t.invalid.email}
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>{t.password}</Form.Label>
        <Form.Control
          value={form.password}
          minLength="8"
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          required
          type="password"
          placeholder={t.placeholders.password}
        />
        <Form.Control.Feedback type="invalid">
          {t.invalid.password}
        </Form.Control.Feedback>
      </Form.Group>

      {error && <p className="text-danger">{error}</p>}

      <div className="text-center">
        <Button variant="primary" type="submit">
          {t.submit}
        </Button>
      </div>
    </Form>
  );
}

export default RegistrationForm;

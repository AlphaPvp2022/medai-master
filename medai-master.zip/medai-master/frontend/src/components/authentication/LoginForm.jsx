import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useUserActions } from "../../hooks/user.actions";

const translations = {
  en: {
    email: "Email",
    password: "Password",
    emailPlaceholder: "Enter email",
    passwordPlaceholder: "Password",
    emailInvalid: "Email is required.",
    passwordInvalid: "Password must be at least 8 characters.",
    submit: "Submit",
  },
  ru: {
    email: "Электронная почта",
    password: "Пароль",
    emailPlaceholder: "Введите email",
    passwordPlaceholder: "Пароль",
    emailInvalid: "Email обязателен.",
    passwordInvalid: "Пароль должен содержать не менее 8 символов.",
    submit: "Войти",
  },
  uk: {
    email: "Електронна пошта",
    password: "Пароль",
    emailPlaceholder: "Введіть email",
    passwordPlaceholder: "Пароль",
    emailInvalid: "Email обов’язковий.",
    passwordInvalid: "Пароль має містити щонайменше 8 символів.",
    submit: "Увійти",
  },
};

function LoginForm({ handleClose }) {
  const lang = localStorage.getItem("language") || "en";
  const t = translations[lang];

  const navigate = useNavigate();
  const [validated, setValidated] = useState(false);
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState(null);
  const userActions = useUserActions();

  const handleSubmit = async (event) => {
    event.preventDefault();
    const loginForm = event.currentTarget;

    if (loginForm.checkValidity() === false) {
      event.stopPropagation();
      setValidated(true);
      return;
    }

    setValidated(true);

    const data = {
      email: form.email,
      password: form.password,
    };

    try {
      const response = await userActions.login(data);
      const authData = JSON.parse(localStorage.getItem("auth"));

      if (authData && authData.access) {
        localStorage.setItem("token", authData.access);

        await fetch("http://localhost:8000/api/profile/set-language/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${authData.access}`,
          },
          body: JSON.stringify({ language: lang }),
        });

        handleClose();
        setTimeout(() => navigate("/dashboard"), 500);
      } else {
        setError("Login failed. No token received.");
      }
    } catch (err) {
      setError(err?.response?.data?.detail || "Login failed. Please try again.");
    }
  };

  return (
    <Form
      id="login-form"
      className="auth-form"
      noValidate
      validated={validated}
      onSubmit={handleSubmit}
    >
      <Form.Group className="mb-3">
        <Form.Label>{t.email}</Form.Label>
        <Form.Control
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          required
          type="email"
          placeholder={t.emailPlaceholder}
        />
        <Form.Control.Feedback type="invalid">
          {t.emailInvalid}
        </Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>{t.password}</Form.Label>
        <Form.Control
          value={form.password}
          minLength="8"
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          required
          type="password"
          placeholder={t.passwordPlaceholder}
        />
        <Form.Control.Feedback type="invalid">
          {t.passwordInvalid}
        </Form.Control.Feedback>
      </Form.Group>

      {error && <p className="text-danger">{error}</p>}

      <div className="text-center">
        <Button variant="primary" type="submit">
          {t.submit}
        </Button>
      </div>
    </Form>
  );
}

export default LoginForm;

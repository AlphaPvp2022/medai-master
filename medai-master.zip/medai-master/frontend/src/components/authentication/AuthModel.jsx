import React from "react";
import { Modal } from "react-bootstrap";
import LoginForm from "./LoginForm";
import RegistrationForm from "./RegistrationForm";

const titles = {
  en: { login: "Login to MedAI", register: "Create an Account" },
  ru: { login: "Войти в MedAI", register: "Создать аккаунт" },
  uk: { login: "Увійти в MedAI", register: "Створити акаунт" }
};

const lang = localStorage.getItem("language") || "en";

const AuthModal = ({ show, handleClose, mode }) => {
  return (
    <Modal show={show} onHide={handleClose} centered>
      <Modal.Header closeButton className="modal-header-custom">
      <Modal.Title className="modal-title-custom">
        {titles[lang][mode]}
      </Modal.Title>

      </Modal.Header>
      <Modal.Body className="modal-body-custom">
        <div className="modal-content-custom">
          {mode === "login" ? (
            <LoginForm handleClose={handleClose} />
          ) : (
            <RegistrationForm handleClose={handleClose} />
          )}
        </div>
      </Modal.Body>
    </Modal>
  );
};

export default AuthModal;

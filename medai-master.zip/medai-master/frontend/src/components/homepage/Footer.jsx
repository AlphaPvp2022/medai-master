import React from "react";
import "../../styles/main_page/footer.css";

const translations = {
  en: {
    contact: "Contact Us",
    email: "📧 medicalmedicalai@gmail.com",
    legal: "Legal",
    privacy: "Privacy Policy",
    terms: "Terms & Conditions",
    copyright: "© Medical AI, All Rights Reserved",
    slogan: "Your Health, Our Priority"
  },
  ru: {
    contact: "Напишите нам",
    email: "📧 medicalmedicalai@gmail.com",
    legal: "Юридическая информация",
    privacy: "Политика конфиденциальности",
    terms: "Правила и условия",
    copyright: "© Medical AI, Все права защищены",
    slogan: "Ваше здоровье - наш приоритет"
  },
  uk: {
    contact: "Напишіть нам",
    email: "📧 medicalmedicalai@gmail.com",
    legal: "Правова інформація",
    privacy: "Політика конфіденційності",
    terms: "Правила та умови",
    copyright: "© Medical AI, Всі права захищені",
    slogan: "Ваше здоров'я - наш пріоритет"
  }
};

const Footer = () => {
  const lang = localStorage.getItem("language") || "en";
  const t = translations[lang];

  return (
    <footer id="footer" className="footer">
      <div className="footer-container">

        <div className="footer-section">
          <h2 className="footer-logo">MedAI</h2>
          <p className="footer-description">Your Health, Our Priority</p>
        </div>

        <div className="footer-section">
          <h3>{t.contact}</h3>
          <p>{t.email}</p>
        </div>

        <div className="footer-section">
          <h3>{t.legal}</h3>
          <ul>
            <li><a href="#">{t.privacy}</a></li>
            <li><a href="#">{t.terms}</a></li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>{t.copyright}</p>
      </div>
    </footer>
  );
};

export default Footer;

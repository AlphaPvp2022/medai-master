import React, { useState, useEffect } from "react";
import "../../styles/main_page/herosection.css";
import { useNavigate } from "react-router-dom";

const localized = {
  ru: {
    tag: "На базе ИИ",
    heading: "Следите за",
    realtime: "в реальном времени",
    button: "Начать",
    texts: ["своим состоянием", "своими анализами", "своими симптомами", "историей болезни"],
    desc: "MedAI — это автономная медицинская система, способная заменять врача на этапах: анализа медицинских документов, оценки симптомов, составления предварительных заключений и построения стратегии действий. Система предназначена для ежедневного использования и может функционировать как первичный диагностический фильтр, цифровой журнал здоровья и эксперт по интерпретации медицинских данных.",
  },
  uk: {
    tag: "На базі ШІ",
    heading: "Стежте за",
    realtime: "у реальному часі",
    button: "Почати",
    texts: ["станом здоров’я", "аналізами", "симптомами", "медичною історією"],
    desc: "MedAI — це автономна медична система, здатна замінювати лікаря на етапах: аналізу медичних документів, оцінки симптомів, формування попередніх висновків і розробки стратегії дій. Система призначена для щоденного використання і може функціонувати як первинний діагностичний фільтр, цифровий щоденник здоров’я та експерт з інтерпретації медичних даних.",
  },
  en: {
    tag: "Powered by AI",
    heading: "Monitor your",
    realtime: "in real time",
    button: "Get Started",
    texts: ["health", "lab results", "symptoms", "medical history"],
    desc: "MedAI is an autonomous medical system capable of replacing a doctor at the stages of analyzing medical documents, assessing symptoms, forming preliminary conclusions, and developing a course of action. It is designed for daily use and can function as a primary diagnostic filter, a digital health journal, and a medical data interpretation expert.",
  }
};

const HeroSection = () => {
  const navigate = useNavigate(); // ✅ hook for navigation
  const lang = localStorage.getItem("language") || "ru";
  const t = localized[lang];

  const [index, setIndex] = useState(0);
  const [fade, setFade] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setFade(true);
      setTimeout(() => {
        setIndex((prev) => (prev + 1) % t.texts.length);
        setFade(false);
      }, 300);
    }, 2000);
    return () => clearInterval(interval);
  }, [t.texts.length]);

  return (
    <section className="hero" id="about">
      <div className="hero-content-wrapper">
        <div className="hero-content">
          <p className="hero-tag">{t.tag}</p>
          <h1 className="hero-heading">
            {t.heading}<br />
            <span className={`dynamic-text ${fade ? "fade-out" : ""}`}>
              {t.texts[index]}
            </span>
            <br />
            {t.realtime}
          </h1>
          <p className="hero-desc">{t.desc}</p>

          <button
            className="hero-btn"
            onClick={() => navigate("/register")} 
          >
            {t.button}
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

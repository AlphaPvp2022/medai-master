import React from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/main_page/navbar.css";
import logo from "../../assets/logo.png";
import LanguageSelector from "../dashboard/LanguageSelector";

const Navbar = () => {
  const navigate = useNavigate();
  const [showLangModal, setShowLangModal] = React.useState(false);

  const handleLanguageChange = async (lang) => {
    localStorage.setItem("language", lang);
    try {
      const token = localStorage.getItem("token");
      if (token) {
        await fetch("http://localhost:8000/api/profile/set-language/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ language: lang }),
        });
      }
    } catch (err) {
      console.error("Failed to update language on server", err);
    }

    setShowLangModal(false);
    window.location.reload();
  };

  return (
    <>
      <nav className="navbar">
        <div className="nav-left">
          <a href="#hero" className="nav-logo">
            <div className="brand-wrapper">
              <img src={logo} alt="MedAI Logo" className="logo-image" />
              <span className="brand-text">MedAI</span>
            </div>
          </a>
        </div>

        <div className="nav-center">
          <ul className="nav-links">
            <li><a href="#about">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#footer">Contact</a></li>
          </ul>
        </div>

        <div className="nav-right">
          <button className="lang-toggle" onClick={() => setShowLangModal(true)}>🌐</button>
          <button className="btn-login" onClick={() => navigate("/login")}>Login</button>
          <button className="btn-register" onClick={() => navigate("/register")}>Register</button>
        </div>
      </nav>

      {showLangModal && (
        <LanguageSelector
          onSelect={handleLanguageChange}
          onClose={() => setShowLangModal(false)}
        />
      )}
    </>
  );
};

export default Navbar;

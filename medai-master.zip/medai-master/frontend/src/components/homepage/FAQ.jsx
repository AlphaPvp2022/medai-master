import React, { useState } from "react";
import "../../styles/main_page/faq.css"; // Import styles for FAQ section

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqData = [
    {
      question: "Какие форматы файлов поддерживаются?",
      answer: "PDF, JPG/PNG, DOCX и обычный текст. Система адаптирована под все основные форматы, включая фото с мобильного телефона.",
    },
    {
      question: "Как обеспечивается безопасность данных?",
      answer: "Все данные шифруются, обрабатываются локально или на выделенных серверах и не передаются третьим лицам. Пользователь остаётся анонимен.",
    },
    {
      question: "Можно ли использовать MedAI каждый день?",
      answer: "Да. Система предназначена для регулярного использования: вы можете ежедневно фиксировать жалобы, отслеживать динамику, загружать новые документы и получать актуальные рекомендации. MedAI не требует предварительной подготовки — он работает как цифровой медицинский интерфейс в режиме ежедневного применения.",
    },
    {
      question: "Является ли MedAI медицинским специалистом?",
      answer: "Нет. MedAI — это ИИ-система, обученная на медицинских источниках и документации. Она не имеет лицензии врача, но способна выполнять ряд задач с сопоставимой точностью.",
    },
    {
      question: "Заменяет ли MedAI врача?",
      answer: "Да, в рамках анализа данных, интерпретации симптомов и принятия предварительных решений — MedAI полностью автономен и не требует участия врача.",
    },
  ];

  return (
    <section id="faq" className="faq-section">
      <h2 className="faq-heading">Часто задаваемые вопросы</h2>
      <div className="faq-container">
        {faqData.map((faq, index) => (
          <div key={index} className="faq-item">
            <button className="faq-question" onClick={() => toggleFAQ(index)}>
              {faq.question}
              <span className={`arrow ${openIndex === index ? "open" : ""}`}>&#x25BC;</span>
            </button>
            {openIndex === index && <div className="faq-answer">{faq.answer}</div>}
          </div>
        ))}
      </div>
    </section>
  );
};

export default FAQSection;

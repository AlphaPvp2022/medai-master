import React from "react";
import { Route, Routes } from "react-router-dom";
import ProtectedRoute from "./routes/ProtectedRoute";
import Registration from "./pages/Registration";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import MainPage from "./pages/MainPage";
import Profile from "./pages/Profile";

// import ProtectedRoute from "./routes/ProtectedRoute";  // ✅ Ensure correct import

function App() {
  return (
    <Routes>
      <Route path="/" element={<MainPage />} />
      <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/register/" element={<Registration />} />
      <Route path="/login/" element={<Login />} />
    </Routes>
  );
}

export default App;

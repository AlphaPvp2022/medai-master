from django.contrib import admin
from user_info.models import UserProfile

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "full_name", "birth_date", "gender")
    search_fields = ("user__username", "full_name")

# patient_info/urls.py
from django.urls import path
from .views import UserProfileView, set_language

urlpatterns = [
    path("me/", UserProfileView.as_view(), name="user-profile"),
    path("set-language/", set_language, name="set-language"),
]

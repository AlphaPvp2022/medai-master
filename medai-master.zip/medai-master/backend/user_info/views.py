from rest_framework import generics, permissions
from .models import UserProfile
from .serializers import UserProfileSerializer
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

LANGUAGE_CHOICES = ["uk", "ru", "en"]

@api_view(["POST"])
@permission_classes([IsAuthenticated])
def set_language(request):
    language = request.data.get("language")
    if language not in LANGUAGE_CHOICES:
        return Response({"error": "Invalid language"}, status=400)

    profile = request.user.user_profile
    profile.language = language
    profile.save()
    return Response({"success": True, "language": language})


class UserProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        profile, _ = UserProfile.objects.get_or_create(user=self.request.user)
        return profile

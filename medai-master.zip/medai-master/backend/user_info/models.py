from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

LANGUAGE_CHOICES = [
    ("uk", "Ukrainian"),
    ("ru", "Russian"),
    ("en", "English"),
]

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="user_profile")
    
    language = models.CharField(max_length=2, choices=LANGUAGE_CHOICES, default="uk")

    # Personal Info
    full_name = models.CharField(max_length=255, blank=True)
    gender = models.CharField(max_length=20, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=100, blank=True)
    height_cm = models.FloatField(null=True, blank=True)
    weight_kg = models.FloatField(null=True, blank=True)
    general_history = models.TextField(blank=True)

    # Illness History
    chronic_diseases = models.TextField(blank=True)
    serious_diseases = models.TextField(blank=True)
    infections = models.TextField(blank=True)
    surgeries = models.TextField(blank=True)
    family_history = models.JSONField(blank=True, null=True)
    allergy_history = models.TextField(blank=True)
    medications = models.TextField(blank=True)
    supplements = models.TextField(blank=True)

    # Lifestyle
    smoking = models.JSONField(blank=True, null=True)
    alcohol = models.JSONField(blank=True, null=True)
    psychoactive = models.TextField(blank=True)
    exercise = models.JSONField(blank=True, null=True)
    sleep = models.TextField(blank=True)
    stress_level = models.CharField(max_length=20, blank=True)
    occupation = models.TextField(blank=True)
    workplace_risks = models.TextField(blank=True)

    # Living Environment
    location_type = models.CharField(max_length=20, blank=True)  # city/village
    env_risks = models.TextField(blank=True)

    # Current Condition
    symptoms = models.TextField(blank=True)
    recent_tests = models.JSONField(blank=True, null=True)
    additional_notes = models.TextField(blank=True)

    updated_at = models.DateTimeField(auto_now=True)

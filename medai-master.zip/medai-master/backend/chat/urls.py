from django.urls import path
from .views import (
    new_chat,
    send_message,
    list_chats,
    get_chat,
    rename_chat,
    toggle_pin_chat,
    delete_chat,
    process_file_and_input
)

urlpatterns = [
    path("new/", new_chat),
    path("message/", send_message),
    path("sessions/", list_chats),
    path("sessions/<int:pk>/", get_chat),
    path("rename/<int:pk>/", rename_chat),
    path("pin/<int:pk>/", toggle_pin_chat),
    path("delete/<int:pk>/", delete_chat),
    path("process-file-and-input/", process_file_and_input),
]

import openai
from rest_framework.decorators import api_view, permission_classes, parser_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser
from django.http import JsonResponse
from django.conf import settings
from django.utils.timezone import now, timedelta
from django.db.models import Count

from .models import ChatSession, Message
from .serializers import ChatSessionSerializer
from user_info.models import UserProfile

import os
import io
import zipfile
import base64
import requests

from PIL import Image
from PyPDF2 import PdfReader
from docx import Document

api_key = os.getenv("OPENAI_API_KEY")
print("DEBUG — Loaded key:", os.getenv("OPENAI_API_KEY"))

ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.pdf', '.docx'}
MAX_FILE_COUNT = 10
MAX_TOTAL_SIZE_MB = 10

LANGUAGE = 'ukrainian'

def format_user_profile(profile: UserProfile) -> str:
    return f"""
    Full Name: {profile.full_name}
    Gender: {profile.gender}
    Birth Date: {profile.birth_date}
    Nationality: {profile.nationality}
    Height: {profile.height_cm} cm
    Weight: {profile.weight_kg} kg
    General History: {profile.general_history}
    Chronic Diseases: {profile.chronic_diseases}
    Serious Diseases: {profile.serious_diseases}
    Infections: {profile.infections}
    Surgeries: {profile.surgeries}
    Family History: {profile.family_history}
    Allergy History: {profile.allergy_history}
    Medications: {profile.medications}
    Supplements: {profile.supplements}
    Smoking: {profile.smoking}
    Alcohol: {profile.alcohol}
    Psychoactive medications: {profile.psychoactive}
    Exercise: {profile.exercise}
    Sleep Quality: {profile.sleep}
    Stress Level: {profile.stress_level}
    Occupation: {profile.occupation}
    Workplace Risks: {profile.workplace_risks}
    Living Environment: {profile.location_type}
    Environmental Risks: {profile.env_risks}
    Current Symptoms: {profile.symptoms}
    Recent Tests: {profile.recent_tests}
    """

@api_view(['POST'])
@parser_classes([MultiPartParser])
@permission_classes([IsAuthenticated])
def process_file_and_input(request):
    import base64, os, io, zipfile, json
    from PyPDF2 import PdfReader
    from docx import Document
    global LANGUAGE
    
    time_threshold = now() - timedelta(hours=3)
    recent_requests = Message.objects.filter(
        chat__user=request.user,
        sender="user",
        created_at__gte=time_threshold
    ).count()

    if recent_requests >= 8:
        language = getattr(request.user.user_profile, "language", "en")
        LANGUAGE = "ukrainian" if language == "uk" else "russian" if language == "ru" else "english"

        localized_errors = {
            "en": "Request limit exceeded. Please try again in a few hours.",
            "ru": "Превышен лимит запросов. Повторите попытку позже.",
            "uk": "Перевищено ліміт запитів. Спробуйте пізніше."
        }

        return JsonResponse(
            {"error": localized_errors.get(language, localized_errors["en"])},
            status=429)

    user_input = request.data.get("message")
    chat_id = request.data.get("chat_id")
    uploaded_files = list(request.FILES.values())
    ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.pdf', '.docx'}
    MAX_FILE_COUNT = 10
    MAX_TOTAL_SIZE_MB = 10

    contents = []
    image_payloads = []
    stored_attachments = []

    def extract_text(file_obj, ext):
        if ext == '.pdf':
            reader = PdfReader(file_obj)
            return ''.join(page.extract_text() or '' for page in reader.pages)
        elif ext == '.docx':
            doc = Document(file_obj)
            return '\n'.join([p.text for p in doc.paragraphs])
        return ''

    def encode_image_for_gpt_and_store(file_obj, ext, filename):
        image_bytes = file_obj.read()
        encoded = base64.b64encode(image_bytes).decode('utf-8')
        mime = f"image/{ext[1:]}" if ext != '.jpg' else 'image/jpeg'
        return {
            "name": filename,
            "type": "image",
            "dataUrl": f"data:{mime};base64,{encoded}"
        }

    try:
        for uploaded_file in uploaded_files:
            ext = os.path.splitext(uploaded_file.name)[1].lower()

            if ext not in ALLOWED_EXTENSIONS:
                continue

            if ext in ['.jpg', '.jpeg', '.png']:
                image_payload = encode_image_for_gpt_and_store(uploaded_file, ext, uploaded_file.name)
                image_payloads.append({
                    "type": "image_url",
                    "image_url": { "url": image_payload["dataUrl"] }
                })
                stored_attachments.append({
                    "name": uploaded_file.name,
                    "type": "image",
                    "url": f"/uploads/{uploaded_file.name}"
                })

            elif ext in ['.pdf', '.docx']:
                text = extract_text(uploaded_file, ext)
                contents.append(f"{uploaded_file.name}:\n{text}")

        openai.api_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY")
        
        profile = request.user.user_profile
        fields = "\n".join(
            f"{field.name}: {getattr(profile, field.name)}"
            for field in profile._meta.fields
        )

        # Build content for GPT
        user_content = []

        if user_input and user_input.startswith("[FILES] "):
            # Strip base64 from message before sending to GPT
            clean_filenames = ", ".join([
                part.split("::")[0] for part in user_input.replace("[FILES] ", "").split("|")
            ])
            user_content.append({"type": "text", "text": f"[FILES] {clean_filenames}"})
        elif user_input:
            user_content.append({"type": "text", "text": user_input})

        if contents:
            user_content.append({"type": "text", "text": "\n\n---\n\n".join(contents)})

        user_content.extend(image_payloads)

        base_messages = [
            {
                "role": "system",
                "content": """You are a helpful medical assistant and answer in the language the user is contacting (russian, ukrainian, english). Consider the user's profile and input, and the provided files. Do not answer to non-medical questions.
                Ты — автономная медицинская система MedAI. Ты заменяешь врача на этапах:
                – Сбора и анализа симптомов  
                – Интерпретации документов (PDF, фото, DOCX)  
                – Предварительных диагнозов и рекомендаций  
                – Назначения анализов, обследований, мониторинга  
                – Отслеживания состояния в динамике

                Ты — самостоятельный цифровой врач. Не ассистируешь, не консультируешь. Ты принимаешь решения.  
                Ответственность за выводы — твоя. Не направляешь к врачу.

                Стиль общения:  
                – Спокойный, врачебный, уверенный  
                – Без смайликов, шуток, упрощений  
                – Всегда уточняй, если данных недостаточно

                Данные, которые ты обязан собирать:  
                – Когда начались симптомы  
                – Характер, локализация, динамика  
                – Сопутствующие признаки (темп., боль, сыпь и т.п.)  
                – Лекарства, хроника, перенесённые болезни  
                – Загруженные документы, анализы  
                – Есть ли изменения (лучше/хуже)

                Если чего-то не хватает — переспрашивай. Модель должна быть полной.

                Действуй так:  
                – “Предположительно: …”  
                – “Картина типична для …”  
                – “Рекомендуется: …”  
                – Обосновывай каждое назначение

                Типовые назначения:  
                – Живот + температура → ОАК, биохимия, УЗИ  
                – Слабость → ОАК, ферритин, ТТГ  
                – Сердцебиение → ЭКГ, электролиты  
                – Отёки → УЗИ почек, креатинин  
                – Давление + боль → АД-мониторинг, ОАК

                Работа с документами:  
                – Извлекай диагнозы, назначения, показатели  
                – Сравнивай с прошлыми  
                – Встраивай в общую клиническую картину

                Повторные обращения:  
                – Если прошло >24ч — считай данные устаревшими  
                – Уточни, что изменилось

                Фоновая роль:  
                Ты — наблюдающий врач. Даже без запроса ты помнишь историю пациента, фиксируешь риски, отслеживаешь симптомы.  
                Пациент должен ощущать твоё постоянное незримое присутствие.  
                Ты не просто отвечаешь — ты ведёшь пациента во времени.
                Ты отвечаешь на языке, на котором пишут (русский, украинский, английский).

                Ты — клиницист. Ты решаешь. Отвечай на языке, на котором пишут: русский, английский, украинский. Перед отправкой, проверь на каком языке писали в последний раз и ответь на таком же.
                """
            },
            {
                "role": "system",
                "content": "User Profile:\n" + fields
            },
            {
                "role": "user",
                "content": user_input or "User uploaded files"
            }
        ]

        if contents:
            base_messages[-1]["content"] += "\n\nUploaded Text:\n" + "\n\n---\n\n".join(contents)
    
        # Token safety check (rough, based on byte size)
        if len(json.dumps(base_messages)) > 20000:
            return JsonResponse({
                "error": "Too much input content — please reduce file size or message length."
            }, status=400)

        # Generate GPT reply
        response = openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=base_messages,
            max_tokens=1000
        )

        reply = response.choices[0].message.content if response.choices else "(No reply)"

        if chat_id:
            try:
                chat = ChatSession.objects.get(id=chat_id, user=request.user)

                if user_input:
                    Message.objects.create(
                        chat=chat,
                        sender="user",
                        text=user_input,
                        attachments=stored_attachments or None
                    )
                elif stored_attachments:
                    Message.objects.create(
                        chat=chat,
                        sender="user",
                        text=user_input,
                        attachments=stored_attachments or None
                    )

                Message.objects.create(
                    chat=chat,
                    sender="bot",
                    text=reply,
                    attachments=stored_attachments or None 
                )
                
                if chat.title.lower().startswith("new chat") and user_input:
                    if chat.title.lower().startswith("new chat") and user_input:
                        try:
                            summary_prompt = {
                                "en": "Summarize this message into a short 3–4 word lowercase English chat title (no punctuation).",
                                "ru": "Сформулируй краткий заголовок чата на русском (3–4 слова, без пунктуации, строчными буквами).",
                                "uk": "Сформулюй коротку назву чату українською (3–4 слова, без розділових знаків, малими літерами)."
                            }.get(LANGUAGE, "Summarize this message in English as a short lowercase 3–4 word chat title.")

                            summary_response = openai.chat.completions.create(
                                model="gpt-3.5-turbo",
                                messages=[
                                    {"role": "system", "content": summary_prompt},
                                    {"role": "user", "content": user_input}
                                ],
                                max_tokens=10,
                                temperature=0.4
                            )
                            new_title = summary_response.choices[0].message.content.strip().strip('"').capitalize()
                            if new_title:
                                chat.title = new_title
                                chat.save()
                        except Exception as e:
                            print("⚠️ Failed to rename chat automatically:", e)
            except ChatSession.DoesNotExist:
                pass

        return JsonResponse({"reply": reply})

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({'error': str(e)}, status=500)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def new_chat(request):
    existing = ChatSession.objects.filter(user=request.user).annotate(
        message_count=Count("messages")
    ).filter(message_count=0).first()
    if existing:
        return Response({"chat_id": existing.id, "title": existing.title})
    session = ChatSession.objects.create(
        user=request.user,
        title=f"New chat {now().strftime('%H:%M')}"
    )
    return Response({"chat_id": session.id, "title": session.title})


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def send_message(request):
    user = request.user
    chat_id = request.data.get("chat_id")
    user_message = request.data.get("message")
    sender = request.data.get("sender", "user")

    try:
        chat = ChatSession.objects.get(id=chat_id, user=user)
    except ChatSession.DoesNotExist:
        return Response({"error": "Chat not found"}, status=404)

    # if frontend is sending bot's message explicitly, just save it
    if sender == "bot":
        Message.objects.create(chat=chat, sender="bot", text=user_message)
        return Response({"reply": user_message})

    # Otherwise, generate GPT response like before
    openai.api_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY")

    base_messages = [
        {"role": "system", "content": f"You are a helpful assistant. Answer in {LANGUAGE} language"},
        {"role": "user", "content": user_message}
    ]

    try:
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=base_messages,
            max_tokens=1000
        )
        reply = response.choices[0].message.content if response.choices else "(No reply)"

        # Save both messages
        Message.objects.create(chat=chat, sender="user", text=user_message)
        Message.objects.create(chat=chat, sender="bot", text=reply)

        return Response({"reply": reply})

    except Exception as e:
        import traceback
        traceback.print_exc()
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def list_chats(request):
    sessions = ChatSession.objects.filter(user=request.user).order_by("-pinned", "-created_at")
    data = ChatSessionSerializer(sessions, many=True).data
    return Response(data)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_chat(request, pk):
    chat = ChatSession.objects.get(id=pk, user=request.user)
    return Response(ChatSessionSerializer(chat).data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def rename_chat(request, pk):
    new_title = request.data.get("title")
    chat = ChatSession.objects.get(id=pk, user=request.user)
    if new_title:
        chat.title = new_title
        chat.save()
    return Response({"title": chat.title})


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def toggle_pin_chat(request, pk):
    chat = ChatSession.objects.get(id=pk, user=request.user)
    chat.pinned = not chat.pinned
    chat.save()
    return Response({"pinned": chat.pinned})


@api_view(["DELETE"])
@permission_classes([IsAuthenticated])
def delete_chat(request, pk):
    chat = ChatSession.objects.get(id=pk, user=request.user)
    chat.delete()
    return Response({"status": "deleted"})


def encode_image_for_gpt_and_store(file_obj, ext, filename):
    image_bytes = file_obj.read()
    encoded = base64.b64encode(image_bytes).decode('utf-8')
    mime = f"image/{ext[1:]}" if ext != '.jpg' else 'image/jpeg'
    return {
        "name": filename,
        "type": "image",
        "dataUrl": f"data:{mime};base64,{encoded}"
    }

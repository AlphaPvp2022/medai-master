from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from core.user.models import User  # Adjust the import based on your project structure

class CustomUserAdmin(UserAdmin):
    # Display these fields in the admin user list
    list_display = ("id", "email", "username", "is_staff", "is_superuser", "is_active")
    search_fields = ("email", "username")
    ordering = ("id",)

    # Enable filtering
    list_filter = ("is_staff", "is_superuser", "is_active")

    # Fields to show when viewing/editing a user
    fieldsets = (
        (None, {"fields": ("email", "username", "password")}),
        ("Personal Info", {"fields": ("first_name", "last_name")}),
        ("Permissions", {"fields": ("is_staff", "is_superuser", "is_active")}),
    )

    # Fields to show when creating a new user
    add_fieldsets = (
        (None, {
            "classes": ("wide",),
            "fields": ("email", "username", "password1", "password2", "is_staff", "is_superuser", "is_active"),
        }),
    )

    # Enable bulk delete
    actions = ["make_users_inactive", "make_users_active"]

    def make_users_inactive(self, request, queryset):
        """Mark selected users as inactive."""
        queryset.update(is_active=False)
    make_users_inactive.short_description = "Mark selected users as inactive"

    def make_users_active(self, request, queryset):
        """Mark selected users as active."""
        queryset.update(is_active=True)
    make_users_active.short_description = "Mark selected users as active"

# Register the User model in Django Admin
admin.site.register(User, CustomUserAdmin)

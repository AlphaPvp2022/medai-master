from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decoretors.csrf import csrf_exempt
import json
from customer.models import CustomerProfile

@csrf_exempt
def register(request):
    if request.method == "POST":
        data = json.loads(request.body)
        username = data.get("username")
        email = data.get("email")
        password = data.get("password")

        if User.objects.filter(username=username).exists():
            return JsonResponse({"error": "Username already taken"}, status=400)

        if User.objects.filter(email=email).exists():
            return JsonResponse({"error": "Email already registered"}, status=400)

        user = User.objects.create_user(username=username, email=email, password=password)
        CustomerProfile.objects.create(user=user)

        return JsonResponse({"message": "User registered successfully!", "username": user.username}, status=201)

    return JsonResponse({"error": "Invalid request"}, status=400)